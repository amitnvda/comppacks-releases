/* hostscript.jsx — CompPack ExtendScript entry point
   Recompiles on AE restart. All functions called via cs.evalScript() from panel/app.js.
*/

// Capture script path at load time ($.fileName may be empty inside evalScript calls)
var _cpScriptPath = $.fileName; // → .../ae-template-studio/jsx/hostscript.jsx

// ── Read image file → base64 string ─────────────────────────────────────

function clReadImageBase64(filePath) {
  try {
    var f = new File(filePath);
    if (!f.exists) return 'ERROR:not found';
    f.encoding = 'BINARY';
    if (!f.open('r')) return 'ERROR:cannot open';
    var binary = f.read();
    f.close();
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var b64 = '';
    var len = binary.length;
    for (var i = 0; i < len; i += 3) {
      var b0 = binary.charCodeAt(i) & 0xff;
      var b1 = (i + 1 < len) ? (binary.charCodeAt(i + 1) & 0xff) : 0;
      var b2 = (i + 2 < len) ? (binary.charCodeAt(i + 2) & 0xff) : 0;
      b64 += chars[b0 >> 2];
      b64 += chars[((b0 & 3) << 4) | (b1 >> 4)];
      b64 += (i + 1 < len) ? chars[((b1 & 0xf) << 2) | (b2 >> 6)] : '=';
      b64 += (i + 2 < len) ? chars[b2 & 0x3f] : '=';
    }
    return 'OK:' + b64;
  } catch (e) {
    return 'ERROR:' + e.toString();
  }
}

// ── Folder picker ─────────────────────────────────────────────────────────

function clSelectFolder() {
  try {
    var folder = Folder.selectDialog('Select CompPack library folder');
    if (!folder) return 'CANCELLED';
    return 'OK:' + folder.fsName;
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// ── Default library folder path ───────────────────────────────────────────

function clGetDefaultFolder() {
  try {
    return 'OK:' + Folder.myDocuments.fsName + '/CompPack Library';
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// ── Ensure library root + /templates subdir exist ─────────────────────────

function clEnsureFolder(root) {
  try {
    var rootF = new Folder(root);
    if (!rootF.exists) rootF.create();
    var subF = new Folder(root + '/templates');
    if (!subF.exists) subF.create();
    return 'OK';
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// ── List all comps from library ───────────────────────────────────────────
// Returns JSON: { ok:true, templates:[{id,name,compName,tags,aepPath,previewPath,templateDir}] }

function clListTemplates(root) {
  try {
    var dir = new Folder(root + '/templates');
    if (!dir.exists) {
      dir.create();
      return JSON.stringify({ ok: true, templates: [] });
    }

    var subfolders = dir.getFiles(function(f) { return f instanceof Folder; });
    var templates  = [];

    for (var i = 0; i < subfolders.length; i++) {
      var sf       = subfolders[i];
      var metaFile = new File(sf.fsName + '/meta.json');
      var aepFile  = new File(sf.fsName + '/comp.aep');
      if (!metaFile.exists || !aepFile.exists) continue;

      try {
        metaFile.open('r');
        var raw = metaFile.read();
        metaFile.close();

        var meta     = JSON.parse(raw);
        meta.id          = sf.name;
        meta.aepPath     = aepFile.fsName;
        meta.templateDir = sf.fsName;

        // Find preview image — png preferred over jpg
        meta.previewPath = '';
        var prevExts = ['png', 'jpg', 'jpeg'];
        for (var pi = 0; pi < prevExts.length; pi++) {
          var pf = new File(sf.fsName + '/preview.' + prevExts[pi]);
          if (pf.exists) { meta.previewPath = pf.fsName; break; }
        }

        templates.push(meta);
      } catch (_) {
        try { metaFile.close(); } catch (__) {}
      }
    }

    templates.sort(function(a, b) {
      return (a.name || '').toLowerCase() > (b.name || '').toLowerCase() ? 1 : -1;
    });

    return JSON.stringify({ ok: true, templates: templates });
  } catch (e) {
    return JSON.stringify({ ok: false, error: e.message });
  }
}

// ── Add selected comp to CompPack ─────────────────────────────────────────
// Flow:
//   1. Validate: active item must be a CompItem, project must be saved.
//   2. reduceProject([comp])  — strips everything not needed by this comp tree.
//   3. Render a single preview frame via the render queue.
//   4. app.project.save(dest/comp.aep)  — saves the minimal, clean .aep.
//   5. Write meta.json.
//   6. app.open(origFile)  — restores the original project from disk.
//
// Returns "OK:<compName>", "OK_NOPREVIEW:<compName>", or "ERROR:<msg>"

function clAddSelectedComp(root) {
  var origFile = null;

  try {
    // ── 1. Validate ──────────────────────────────────────────────────────
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
      return 'ERROR:Select a comp in the Project panel first.';
    }
    if (!app.project.file) {
      return 'ERROR:Save your project first (Cmd+S), then try again.';
    }

    origFile     = app.project.file;
    var compName = comp.name;

    // ── 2. Create destination folder ──────────────────────────────────────
    var slug = compName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (!slug) slug = 'comp-' + (new Date()).getTime();

    var templDir = new Folder(root + '/templates');
    if (!templDir.exists) templDir.create();

    var dest = new Folder(templDir.fsName + '/' + slug);
    var n = 0;
    while (dest.exists) { n++; dest = new Folder(templDir.fsName + '/' + slug + '-' + n); }
    dest.create();

    // ── 3. Reduce project to comp + its full dependency tree ──────────────
    // Removes all items not needed by this comp (pre-comps, unused footage, etc.)
    app.project.reduceProject([comp]);

    // ── 4. Render preview frame ───────────────────────────────────────────
    var hasPreview = _renderPreviewFrameWithFallback(comp, dest.fsName);

    // ── 5. Save the reduced project as the template .aep ─────────────────
    app.project.save(new File(dest.fsName + '/comp.aep'));

    // ── 6. Write meta.json ────────────────────────────────────────────────
    var d     = new Date();
    var today = d.getFullYear() + '-' +
                ('0' + (d.getMonth() + 1)).slice(-2) + '-' +
                ('0' + d.getDate()).slice(-2);

    var meta     = {
      name:      compName,
      compName:  compName,
      tags:      [],
      folder:    '',
      starred:   false,
      addedAt:   today,
      width:     comp.width,
      height:    comp.height,
      duration:  Math.round(comp.duration * 100) / 100,
      frameRate: Math.round(comp.frameRate)
    };
    var metaFile = new File(dest.fsName + '/meta.json');
    metaFile.open('w');
    metaFile.write(JSON.stringify(meta));
    metaFile.close();

    // ── 7. Restore original project ───────────────────────────────────────
    // Suppress dialogs: render queue modifications count as unsaved changes on
    // some AE/Windows versions, which would trigger a save dialog on open.
    app.beginSuppressDialogs();
    app.open(origFile);
    app.endSuppressDialogs(false);
    _restorePanelFocus();

    return hasPreview ? 'OK:' + compName : 'OK_NOPREVIEW:' + compName;

  } catch (e) {
    // Always try to restore the original on error
    if (origFile) {
      try { app.beginSuppressDialogs(); app.open(origFile); app.endSuppressDialogs(false); } catch (_) {}
    }
    return 'ERROR:' + e.message;
  }
}

// ── Render a single preview frame via AE render queue ────────────────────
// Temporarily unqueues any existing RQ items, adds a single-frame PNG/JPEG
// render, runs it, renames output to preview.png/jpg, restores the queue.
// Returns true on success, false if no preview could be captured.

// Returns the full path of the saved preview file, or '' on failure.
function _renderPreviewFrame(comp, destFolderPath) {
  var rq = app.project.renderQueue;

  // Render to a temp folder with no spaces — AE's render queue ignores om.file
  // assignments when the path contains spaces (e.g. "CompPack Library").
  // On Windows, Folder.temp can be inside the user profile (e.g. C:/Users/John Smith/...)
  // which also has spaces if the username contains a space. Use the drive root instead.
  var isWin = ($.os.toLowerCase().indexOf('windows') >= 0);
  var tmpBase;
  if (isWin) {
    // Avoid usernames with spaces (e.g. "John Smith") by using the drive root.
    // Fall back to Folder.temp if drive letter cannot be extracted (unusual setups).
    var driveMatch = Folder.temp.fsName.match(/^([A-Za-z]:)/);
    tmpBase = driveMatch ? driveMatch[1] + '/cppreview' : Folder.temp.fsName + '/cppreview';
  } else {
    tmpBase = Folder.temp.fsName + '/cppreview';
  }
  var tmpFolder = new Folder(tmpBase);
  var tmpDir    = tmpFolder.fsName;
  if (!tmpFolder.exists) tmpFolder.create();

  try {
    // Remove all existing render queue items (they may have stale paths from the
    // original machine the .aep was created on — we only want our single preview item).
    for (var j = rq.numItems; j >= 1; j--) {
      try { rq.items[j].remove(); } catch (e2) {}
    }

    var rqi = rq.items.add(comp);

    // Capture at the middle — most likely to contain visible content
    // (intros have animated in, outros haven't started fading out).
    var totalFrames  = Math.floor(comp.duration / comp.frameDuration);
    var targetFrame  = Math.max(0, Math.floor(totalFrames * 0.50));
    rqi.timeSpanStart    = targetFrame * comp.frameDuration;
    rqi.timeSpanDuration = comp.frameDuration;

    var om  = rqi.outputModules[1];
    var ext = 'png';
    var ok  = false;

    // Build candidate template list: non-Custom built-ins first, then Custom as
    // last resort, then hardcoded English names.
    var availableTemplates = [];
    try { availableTemplates = om.templates || []; } catch (_) {}

    var pngT = null, jpegT = null, psdT = null, tifT = null;
    var cpngT = null, cjpegT = null;   // Custom: fallbacks
    for (var ai = 0; ai < availableTemplates.length; ai++) {
      var tn = availableTemplates[ai];
      var tl = tn.toLowerCase();
      var isCustom = (tl.indexOf('custom') === 0);
      if (!isCustom) {
        if (!pngT  && tl.indexOf('png')  >= 0) pngT  = tn;
        if (!jpegT && (tl.indexOf('jpeg') >= 0 || tl.indexOf('jpg') >= 0)) jpegT = tn;
        if (!psdT  && tl.indexOf('photoshop') >= 0) psdT = tn;
        if (!tifT  && tl.indexOf('tiff') >= 0) tifT  = tn;
      } else {
        if (!cpngT  && tl.indexOf('png')  >= 0) cpngT  = tn;
        if (!cjpegT && (tl.indexOf('jpeg') >= 0 || tl.indexOf('jpg') >= 0)) cjpegT = tn;
      }
    }

    var tryTemplates = [];
    if (pngT)   tryTemplates.push([pngT,   'png']);
    if (jpegT)  tryTemplates.push([jpegT,  'jpg']);
    if (psdT)   tryTemplates.push([psdT,   'psd']);
    if (tifT)   tryTemplates.push([tifT,   'tif']);
    // Hardcoded English built-ins
    tryTemplates.push(['PNG Sequence', 'png'], ['JPEG Sequence', 'jpg'],
                      ['Photoshop Sequence', 'psd'], ['TIFF Sequence', 'tif']);
    // Custom templates as absolute last resort (path overridden by tmpDir below)
    if (cpngT)  tryTemplates.push([cpngT,  'png']);
    if (cjpegT) tryTemplates.push([cjpegT, 'jpg']);

    for (var ti = 0; ti < tryTemplates.length; ti++) {
      try {
        om.applyTemplate(tryTemplates[ti][0]);
        ext = tryTemplates[ti][1];
        ok  = true;
        break;
      } catch (e3) {}
    }

    if (!ok) {
      try { rqi.remove(); } catch (_) {}
      return '';
    }

    // Always render to the space-free temp dir
    om.file = new File(tmpDir + '/_prev.' + ext);
    // Note: rqi.status is read-only in newer AE versions — items added via
    // rq.items.add() are already QUEUED by default, no need to set it.

    // Snapshot temp folder so we can identify the new file
    var existingMap = {};
    var filesBefore = tmpFolder.getFiles('*') || [];
    for (var bi = 0; bi < filesBefore.length; bi++) {
      existingMap[filesBefore[bi].name] = true;
    }

    app.beginSuppressDialogs();
    try { rq.render(); } catch (renderErr) {}
    app.endSuppressDialogs(false);

    try { rqi.remove(); } catch (_) {}

    // Find the rendered file in the temp folder
    var imageExtsRe = /\.(png|jpg|jpeg|psd|tif|tiff)$/i;
    var filesAfter  = tmpFolder.getFiles('*') || [];
    var newFiles    = [];
    for (var ni = 0; ni < filesAfter.length; ni++) {
      var af = filesAfter[ni];
      if (af instanceof File && !existingMap[af.name] && imageExtsRe.test(af.name)) {
        newFiles.push(af);
      }
    }
    if (newFiles.length === 0) return '';

    var srcFile = newFiles[0];
    var srcExt  = srcFile.name.split('.').pop().toLowerCase();
    if (srcExt === 'jpeg') srcExt = 'jpg';

    // Convert PSD/TIFF → PNG (cross-platform: sips on macOS, PowerShell on Windows)
    if (srcExt === 'psd' || srcExt === 'tif' || srcExt === 'tiff') {
      var tmpPng  = new File(tmpDir + '/preview_conv.png').fsName;
      var srcPath = srcFile.fsName;
      try {
        var isWin = ($.os.toLowerCase().indexOf('windows') >= 0);
        if (isWin) {
          // PowerShell: System.Drawing handles PSD/TIFF on all Windows versions
          var winSrc  = srcPath.replace(/\//g, '\\');
          var winDest = tmpPng.replace(/\//g, '\\');
          system.callSystem(
            'powershell -NoProfile -Command "Add-Type -AssemblyName System.Drawing; ' +
            '$i=[System.Drawing.Image]::FromFile(\'' + winSrc + '\'); ' +
            '$i.Save(\'' + winDest + '\',[System.Drawing.Imaging.ImageFormat]::Png); ' +
            '$i.Dispose()"'
          );
        } else {
          // macOS: sips is built-in
          system.callSystem('sips -s format png "' + srcPath + '" --out "' + tmpPng + '"');
        }
        if (new File(tmpPng).exists) {
          try { srcFile.remove(); } catch (_) {}
          srcFile = new File(tmpPng);
          srcExt  = 'png';
        }
      } catch (convErr) {}
    }

    // Copy from temp folder to final destination (which may contain spaces)
    var destPreviewPath = destFolderPath + '/preview.' + srcExt;
    var destPreviewFile = new File(destPreviewPath);
    if (destPreviewFile.exists) { try { destPreviewFile.remove(); } catch (_) {} }
    srcFile.copy(destPreviewPath);
    try { srcFile.remove(); } catch (_) {}

    return (new File(destPreviewPath).exists) ? destPreviewPath : '';

  } catch (e) {
    try { app.endSuppressDialogs(false); } catch (_) {}
    return '';
  }
}

// ── Preview render with empty-frame fallback ──────────────────────────────
// Renders the preview at the comp's middle frame. If the result is mostly
// empty (transparent/uniform — typical for animations that fade in/out where
// the middle still happens to be blank), retries with a deterministic
// hash-coloured solid added at the bottom of the layer stack. The solid is
// always removed before this function returns, so the saved .aep is never
// polluted.
function _renderPreviewFrameWithFallback(comp, destFolderPath) {
  var path = _renderPreviewFrame(comp, destFolderPath);
  if (path && _previewLikelyHasContent(path, comp)) return path;

  // Fallback: render against a hash-coloured BG so something is always visible.
  var bgColor = _colorFromString(comp.name || 'comp');
  var tempBG  = null;
  try {
    tempBG = comp.layers.addSolid(bgColor, '_cppreview_bg_tmp', comp.width, comp.height, 1, 1);
    tempBG.moveToEnd();   // bottom of stack — content composes over it
    path = _renderPreviewFrame(comp, destFolderPath);
  } catch (_) {} finally {
    if (tempBG) { try { tempBG.remove(); } catch (__) {} }
  }
  return path;
}

// Heuristic: PNG bytes-per-pixel < 0.05 ⇒ image is essentially uniform
// (all-transparent or single-colour). Real content compresses to 0.1+ bpp.
function _previewLikelyHasContent(filePath, comp) {
  var f = new File(filePath);
  if (!f.exists) return false;
  var pixels = (comp.width * comp.height) || 1;
  return (f.length / pixels) >= 0.05;
}

// Deterministic dark muted RGB triplet derived from a string (djb2 → HSL).
function _colorFromString(str) {
  var hash = 5381;
  for (var i = 0; i < str.length; i++) {
    hash = ((hash * 33) + str.charCodeAt(i)) & 0x7fffffff;
  }
  return _hslToRgb((hash % 360) / 360, 0.40, 0.20);
}

function _hslToRgb(h, s, l) {
  if (s === 0) return [l, l, l];
  var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  var p = 2 * l - q;
  var hue2rgb = function(p, q, t) {
    if (t < 0) t += 1; if (t > 1) t -= 1;
    if (t < 1/6) return p + (q - p) * 6 * t;
    if (t < 1/2) return q;
    if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
    return p;
  };
  return [
    hue2rgb(p, q, h + 1/3),
    hue2rgb(p, q, h),
    hue2rgb(p, q, h - 1/3)
  ];
}

// Re-activate the Composition viewer so the Render Queue panel doesn't stay on top.
function _restorePanelFocus() {
  try {
    var item = app.project.activeItem;
    if (item && item instanceof CompItem) { item.openInViewer(); }
  } catch (_) {}
}

// ── Delete a template folder ──────────────────────────────────────────────
// Returns "OK" or "ERROR:<msg>"

function clDeleteTemplate(templateDir) {
  try {
    var folder = new Folder(templateDir);
    if (!folder.exists) return 'OK';
    var files = folder.getFiles();
    for (var i = 0; i < files.length; i++) { files[i].remove(); }
    folder.remove();
    return 'OK';
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// ── Insert a comp from library into the current project ───────────────────
// 1. Saves a reference to the currently active comp + CTI position.
// 2. Imports the template .aep (reduced, clean).
// 3. Finds the matching CompItem among newly imported items.
// 4. Adds it as a layer in the active comp at the playhead position.
// Returns "OK:<importedName>" or "ERROR:<msg>"

// Returns "OK:<name>" or "ERROR:<msg>"
function clInsertComp(aepPath, compName, displayName) {
  try {
    var f = new File(aepPath);
    if (!f.exists) return 'ERROR:File not found: ' + aepPath;

    // Save active timeline comp + playhead position before import
    var activeComp = null;
    var insertTime = 0;
    if (app.project.activeItem && app.project.activeItem instanceof CompItem) {
      activeComp = app.project.activeItem;
      insertTime = activeComp.time;
    }

    // Snapshot existing item IDs so we can identify what's new after import
    var before = {};
    for (var i = 1; i <= app.project.numItems; i++) {
      before[app.project.items[i].id] = true;
    }

    var opts = new ImportOptions(f);
    // Do NOT set importAs for .aep files — AE imports as project, comps retain their internal names
    app.beginSuppressDialogs();
    try {
      app.project.importFile(opts);
    } catch (importErr) {
      app.endSuppressDialogs(false);
      return 'ERROR:Import failed: ' + importErr.message;
    }
    app.endSuppressDialogs(false);

    // Rename the folder AE creates for the imported .aep (always named "comp.aep")
    // to the template's display name so the project panel stays organised.
    var folderLabel = displayName || compName || 'Comp';
    for (var fi = 1; fi <= app.project.numItems; fi++) {
      var fitem = app.project.items[fi];
      if (!before[fitem.id] && fitem instanceof FolderItem) {
        fitem.name = folderLabel;
        break; // only the top-level import folder needs renaming
      }
    }

    // Find the imported comp — prefer exact name match
    var targetComp = null;
    for (var j = 1; j <= app.project.numItems; j++) {
      var item = app.project.items[j];
      if (!before[item.id] && item instanceof CompItem) {
        if (!targetComp) targetComp = item;          // first new comp as fallback
        if (item.name === compName) { targetComp = item; break; }
      }
    }

    // Place as a layer in the active timeline at the playhead
    if (activeComp && targetComp) {
      try {
        var layer       = activeComp.layers.add(targetComp);
        layer.startTime = insertTime;

        // Mirror comp-level markers onto the inserted layer so they're visible
        // in the parent timeline (and addressable via thisLayer.marker.key(...)).
        // Layer-marker times are in parent-comp time, so offset by insertTime.
        try {
          var srcMarkers = targetComp.markerProperty;
          var dstMarkers = layer.property('Marker');
          if (srcMarkers && dstMarkers) {
            for (var mi = 1; mi <= srcMarkers.numKeys; mi++) {
              dstMarkers.setValueAtTime(
                insertTime + srcMarkers.keyTime(mi),
                srcMarkers.keyValue(mi)
              );
            }
          }
        } catch (_mErr) {} // non-fatal — comp inserted regardless
      } catch (_) {} // non-fatal — comp is still in the project
    }

    var name = targetComp ? targetComp.name : (compName || 'Comp');

    return 'OK:' + name;
  } catch (e) {
    try { app.endSuppressDialogs(false); } catch (_) {}
    return 'ERROR:' + e.message;
  }
}

// ── Update fields in a template's meta.json ───────────────────────────────
// patchJSON: JSON string of key/value pairs to merge, e.g. '{"starred":true}'
// Returns "OK" or "ERROR:<msg>"

function clUpdateMeta(templateDir, patchJSON) {
  try {
    var metaFile = new File(templateDir + '/meta.json');
    if (!metaFile.exists) return 'ERROR:meta.json not found in ' + templateDir;

    metaFile.open('r');
    var raw = metaFile.read();
    metaFile.close();

    var meta  = JSON.parse(raw);
    var patch = JSON.parse(patchJSON);
    for (var key in patch) {
      if (patch.hasOwnProperty(key)) meta[key] = patch[key];
    }

    metaFile.open('w');
    metaFile.write(JSON.stringify(meta));
    metaFile.close();
    return 'OK';
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// ── Read user folder list from _folders.json ──────────────────────────────
// Returns JSON: { ok:true, folders:["Folder A","Folder B"] }

function clGetFolders(root) {
  try {
    var f = new File(root + '/_folders.json');
    if (!f.exists) return JSON.stringify({ ok: true, folders: [] });
    f.open('r');
    var raw = f.read();
    f.close();
    var folders = JSON.parse(raw);
    if (!folders || !(folders instanceof Array)) folders = [];
    return JSON.stringify({ ok: true, folders: folders });
  } catch (e) {
    return JSON.stringify({ ok: false, error: e.message });
  }
}

// ── Write user folder list to _folders.json ───────────────────────────────
// foldersJSON: JSON string array, e.g. '["Intros","Lower Thirds"]'
// Returns "OK" or "ERROR:<msg>"

function clSaveFolders(root, foldersJSON) {
  try {
    var f = new File(root + '/_folders.json');
    f.open('w');
    f.write(foldersJSON);
    f.close();
    return 'OK';
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// ── Check if bundled starter pack exists ──────────────────────────────────
// Returns JSON: { ok:true, count:N, packDir:"..." } or { ok:false }

function clCheckStarterPack() {
  try {
    var extRoot = new File(_cpScriptPath).parent.parent; // jsx/ → ae-template-studio/
    var spDir   = new Folder(extRoot.fsName + '/starter-pack/templates');
    if (!spDir.exists) return JSON.stringify({ ok: false });

    var subs  = spDir.getFiles(function(f) { return f instanceof Folder; });
    var count = 0;
    for (var i = 0; i < subs.length; i++) {
      if (new File(subs[i].fsName + '/comp.aep').exists &&
          new File(subs[i].fsName + '/meta.json').exists) count++;
    }
    if (count === 0) return JSON.stringify({ ok: false });
    return JSON.stringify({ ok: true, count: count, packDir: spDir.fsName });
  } catch (e) {
    return JSON.stringify({ ok: false });
  }
}

// ── Copy a pack folder into the library (skip on slug collision) ───────────
// packDir:     path to a folder containing <slug>/ subfolders
// libraryRoot: the user's CompPack library root
// Returns JSON: { ok:true, installed:N, skipped:N } or { ok:false, error:"..." }

function clInstallPackFrom(packDir, libraryRoot) {
  try {
    var srcDir = new Folder(packDir);
    if (!srcDir.exists) return JSON.stringify({ ok: false, error: 'Pack folder not found.' });

    var destTemplates = new Folder(libraryRoot + '/templates');
    if (!destTemplates.exists) destTemplates.create();

    var subs      = srcDir.getFiles(function(f) { return f instanceof Folder; });
    var installed = 0, skipped = 0;

    for (var i = 0; i < subs.length; i++) {
      var src = subs[i];
      if (!new File(src.fsName + '/comp.aep').exists)  continue;
      if (!new File(src.fsName + '/meta.json').exists) continue;

      var dest = new Folder(destTemplates.fsName + '/' + src.name);
      if (dest.exists) { skipped++; continue; } // never overwrite existing

      dest.create();
      var files = src.getFiles(function(f) { return f instanceof File; });
      for (var j = 0; j < files.length; j++) {
        files[j].copy(dest.fsName + '/' + files[j].name);
      }
      installed++;
    }

    return JSON.stringify({ ok: true, installed: installed, skipped: skipped });
  } catch (e) {
    return JSON.stringify({ ok: false, error: e.message });
  }
}

// ── Update an existing template with the current comp ─────────────────────
// Same flow as clAddSelectedComp but overwrites the existing templateDir.
// Preserves user fields (name, tags, folder, starred, addedAt).
// Updates technical fields (compName, width, height, duration, frameRate).
// Returns "OK:<compName>", "OK_NOPREVIEW:<compName>", or "ERROR:<msg>"

function clUpdateComp(templateDir) {
  var origFile = null;
  try {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
      return 'ERROR:Select a comp in the Project panel first.';
    }
    if (!app.project.file) {
      return 'ERROR:Save your project first (Cmd+S), then try again.';
    }

    origFile = app.project.file;
    var compName = comp.name;

    var dest = new Folder(templateDir);
    if (!dest.exists) return 'ERROR:Template folder not found.';

    // Reduce project to comp + its dependencies
    app.project.reduceProject([comp]);

    // Delete old preview images
    var prevExts = ['png', 'jpg', 'jpeg'];
    for (var pi = 0; pi < prevExts.length; pi++) {
      var pf = new File(templateDir + '/preview.' + prevExts[pi]);
      if (pf.exists) { try { pf.remove(); } catch (_) {} }
    }

    // Render new preview frame
    var hasPreview = _renderPreviewFrameWithFallback(comp, templateDir);

    // Overwrite comp.aep
    app.project.save(new File(templateDir + '/comp.aep'));

    // Update meta.json — preserve user fields, update technical fields.
    // If the file is unreadable/corrupt, fall back to safe defaults so user
    // data (name, tags, folder, starred) is never silently wiped.
    var metaFile = new File(templateDir + '/meta.json');
    var meta = {
      name:    compName,
      tags:    [],
      folder:  '',
      starred: false
    };
    if (metaFile.exists) {
      try {
        metaFile.open('r');
        var parsed = JSON.parse(metaFile.read());
        metaFile.close();
        if (parsed && typeof parsed === 'object') meta = parsed;
      } catch (_) { try { metaFile.close(); } catch (__) {} }
    }
    meta.compName  = compName;
    meta.width     = comp.width;
    meta.height    = comp.height;
    meta.duration  = Math.round(comp.duration * 100) / 100;
    meta.frameRate = Math.round(comp.frameRate);

    metaFile.open('w');
    metaFile.write(JSON.stringify(meta));
    metaFile.close();

    // Restore original project
    app.beginSuppressDialogs();
    app.open(origFile);
    app.endSuppressDialogs(false);
    _restorePanelFocus();

    return hasPreview ? 'OK:' + compName : 'OK_NOPREVIEW:' + compName;
  } catch (e) {
    if (origFile) {
      try { app.beginSuppressDialogs(); app.open(origFile); app.endSuppressDialogs(false); } catch (_) {}
    }
    return 'ERROR:' + e.message;
  }
}

// ── Export selected templates as a shareable pack folder ──────────────────
// templateDirsJSON: JSON array of templateDir paths to include
// packName:         human-readable pack name (used to create the folder)
// parentDir:        parent directory chosen by user
// Returns "OK:<packFolderPath>" or "ERROR:<msg>"

function clExportPack(templateDirsJSON, packName, parentDir) {
  try {
    var dirs = JSON.parse(templateDirsJSON);
    if (!dirs || dirs.length === 0) return 'ERROR:No comps selected.';

    var parent = new Folder(parentDir);
    if (!parent.exists) return 'ERROR:Destination folder not found.';

    // Slugify pack name and find a non-colliding folder name
    var slug = (packName || 'my-comppack').toLowerCase()
                 .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'my-comppack';
    var packDir = new Folder(parent.fsName + '/' + slug);
    var n = 1;
    while (packDir.exists) { n++; packDir = new Folder(parent.fsName + '/' + slug + '-' + n); }
    packDir.create();

    var copied = 0;
    for (var i = 0; i < dirs.length; i++) {
      var src = new Folder(dirs[i]);
      if (!src.exists) continue;

      var dest = new Folder(packDir.fsName + '/' + src.name);
      dest.create();

      var files = src.getFiles(function(f) { return f instanceof File; });
      for (var j = 0; j < files.length; j++) {
        files[j].copy(dest.fsName + '/' + files[j].name);
      }
      copied++;
    }

    if (copied === 0) {
      // Nothing was copied — remove the empty pack folder
      try { packDir.remove(); } catch (_) {}
      return 'ERROR:No valid template folders found.';
    }

    return 'OK:' + packDir.fsName;
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}

// ── Re-capture preview frame for an existing template ─────────────────────
// Opens the template .aep, renders one frame, restores the original project.
// Returns "OK:<previewPath>" or "ERROR:<msg>"

function clRecapturePreview(aepPath, templateDir) {
  var origFile = null;
  try {
    // Save original project reference only if one is open and saved
    if (app.project && app.project.file) {
      origFile = app.project.file;
    }

    var f = new File(aepPath);
    if (!f.exists) return 'ERROR:Template .aep not found.';

    // Open the template project (suppress save-changes dialogs)
    app.beginSuppressDialogs();
    app.open(f);
    app.endSuppressDialogs(false);

    // Find the main comp — prefer the one with the most layers
    var comp = null;
    for (var i = 1; i <= app.project.numItems; i++) {
      var item = app.project.items[i];
      if (item instanceof CompItem) {
        if (!comp || item.numLayers > comp.numLayers) comp = item;
      }
    }

    if (!comp) {
      if (origFile) { app.beginSuppressDialogs(); app.open(origFile); app.endSuppressDialogs(false); }
      return 'ERROR:No comp found in template .aep.';
    }

    // Remove any existing preview images
    var prevExts = ['png', 'jpg', 'jpeg'];
    for (var pi = 0; pi < prevExts.length; pi++) {
      var pf = new File(templateDir + '/preview.' + prevExts[pi]);
      if (pf.exists) { try { pf.remove(); } catch (_) {} }
    }

    // Render a preview frame — returns the preview file path or ''
    var previewPath = _renderPreviewFrameWithFallback(comp, templateDir);

    // Restore the original project (guard: origFile is null when no project was open)
    if (origFile) {
      app.beginSuppressDialogs(); app.open(origFile); app.endSuppressDialogs(false);
    }
    _restorePanelFocus();

    if (!previewPath) return 'ERROR:Preview render failed — check AE render queue.';
    return 'OK:' + previewPath;
  } catch (e) {
    if (origFile) {
      try { app.beginSuppressDialogs(); app.open(origFile); app.endSuppressDialogs(false); } catch (_) {}
    }
    return 'ERROR:' + e.message;
  }
}

// ── Rename a folder across all meta.json files ────────────────────────────
// Updates every template whose folder === oldName, then updates _folders.json.
// Returns "OK" or "ERROR:<msg>"

function clRenameFolder(root, oldName, newName) {
  try {
    var dir        = new Folder(root + '/templates');
    var subfolders = dir.exists ? dir.getFiles(function(f) { return f instanceof Folder; }) : [];

    for (var i = 0; i < subfolders.length; i++) {
      var metaFile = new File(subfolders[i].fsName + '/meta.json');
      if (!metaFile.exists) continue;
      try {
        metaFile.open('r');
        var raw  = metaFile.read();
        metaFile.close();
        var meta = JSON.parse(raw);
        if (meta.folder === oldName) {
          meta.folder = newName;
          metaFile.open('w');
          metaFile.write(JSON.stringify(meta));
          metaFile.close();
        }
      } catch (_) { try { metaFile.close(); } catch (__) {} }
    }

    // Update _folders.json
    var fFile   = new File(root + '/_folders.json');
    var folders = [];
    if (fFile.exists) {
      fFile.open('r');
      try { folders = JSON.parse(fFile.read()); } catch (_) {}
      fFile.close();
    }
    var idx = folders.indexOf(oldName);
    if (idx >= 0) folders[idx] = newName;
    else if (folders.indexOf(newName) < 0) folders.push(newName);

    fFile.open('w');
    fFile.write(JSON.stringify(folders));
    fFile.close();

    return 'OK';
  } catch (e) {
    return 'ERROR:' + e.message;
  }
}
