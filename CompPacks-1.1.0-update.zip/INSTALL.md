# CompPacks — Installation Guide

## Prerequisites

| Requirement | Version |
|---|---|
| Adobe After Effects | 2022+ |

---

## macOS

### Step 1 — Enable CEP Debug Mode
Open **Terminal** and paste all 4 lines, then press Enter:
```bash
defaults write com.adobe.CSXS.9  PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

### Step 2 — Install ZXP Installer
Download and install **ZXP Installer** from [zxpinstaller.com](https://www.zxpinstaller.com/)

### Step 3 — Install the Plugin
Drag `CompPacks-{version}.zxp` into ZXP Installer and click **Install**.

### Step 4 — Restart After Effects
Open AE → **Window → Extensions → CompPacks**

---

## Windows

### Step 1 — Enable CEP Debug Mode
Press `Win + R`, type `cmd`, press `Ctrl + Shift + Enter` (run as Administrator), then paste:
```
reg add "HKCU\Software\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d "1" /f
```

### Step 2 — Install ZXP Installer
Download and install **ZXP Installer** from [zxpinstaller.com](https://www.zxpinstaller.com/)

### Step 3 — Install the Plugin
Drag `CompPacks-{version}.zxp` into ZXP Installer and click **Install**.

### Step 4 — Restart After Effects
Open AE → **Window → Extensions → CompPacks**

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Panel not visible in AE | Check CEP debug mode (Step 1) and restart AE |
