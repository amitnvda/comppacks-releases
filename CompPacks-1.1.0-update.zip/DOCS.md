# CompPacks — Documentation

> **CompPacks** is an Adobe After Effects panel that lets your team build, organize, and share a library of reusable compositions.
>
> Instead of hunting through old projects for that title card or transition you built six months ago — you save it once, and it's one double-click away in every future project. Comps are stored as minimal `.aep` files with a preview thumbnail and metadata, and can be packaged into shareable packs for the whole team.
>
> **Works on macOS and Windows. Installs via ZXP in under two minutes.**

---

A panel for Adobe After Effects that lets you save, organize, and reuse compositions across projects.

---

## Table of Contents

1. [Installation](#installation)
2. [First Launch](#first-launch)
3. [Adding Comps to Your Library](#adding-comps-to-your-library)
4. [Inserting Comps](#inserting-comps)
5. [Organizing Your Library](#organizing-your-library)
6. [Updating & Managing Templates](#updating--managing-templates)
7. [Sharing Packs](#sharing-packs)
8. [Installing Packs](#installing-packs)
9. [Settings](#settings)
10. [Tips & Best Practices](#tips--best-practices)
11. [Troubleshooting](#troubleshooting)

---

## Installation

**Requirements**
- Adobe After Effects CC 2022 or later
- macOS or Windows
- [ZXP Installer](https://www.zxpinstaller.com/) (free)

**Steps**
1. Download and install **ZXP Installer**
2. Drag `CompPacks.zxp` into the ZXP Installer window
3. Click **Install** — if prompted about an untrusted publisher, click **Install Anyway**
4. Launch (or restart) After Effects
5. Go to **Window → Extensions → CompPacks**

---

## First Launch

On first launch the panel will set your library folder to:

| Platform | Default path |
|---|---|
| macOS | `~/Documents/CompPack Library` |
| Windows | `Documents\CompPack Library` |

You can change this at any time in **Settings** (gear icon, top-right).

If your team has shared a starter pack, a banner will appear at the top of the panel — click **Install** to load it into your library.

---

## Adding Comps to Your Library

1. Open or finish building your comp in After Effects
2. **Select the comp** in the AE Project panel (single click)
3. Click **+ Add to CompPack** in the plugin toolbar
4. The plugin will:
   - Reduce the project to the comp and its dependencies only
   - Render a preview frame automatically
   - Save a minimal `.aep` + metadata to your library

> **The project must be saved** before adding a comp. If it isn't, AE will prompt you to save first.

---

## Inserting Comps

1. Browse or search the library
2. **Double-click** a card, or click the **Insert** button on the card
3. The comp is added as a layer in your currently active composition at the current playhead position

> If no comp is open in AE, the comp is still imported into your project — you can drag it manually from the Project panel.

---

## Organizing Your Library

### Search & Sort

- Use the **search bar** to filter by name in real time
- Use the **Sort** dropdown to order by name (A→Z, Z→A) or date (Newest, Oldest)

### Folders

- Click **+ New Folder** in the sidebar to create a folder
- Open a card's **⋮ menu → Move to [Folder]** to assign it
- Click a folder in the sidebar to view only its comps
- Right-click a folder to **Rename** or **Delete** it
  - Deleting a folder moves its comps back to the root — it does not delete the comps

### Favorites

- Click the **star icon** on any card to mark it as a favorite
- Click **Favorites** in the sidebar to view starred comps only

### Tags

- Open the card's **⋮ menu → Edit Tags**
- Enter comma-separated tags (e.g. `title, lower third, animated`)
- Tags appear as chips on the card

### Multi-Select

- Click **Select** in the toolbar to enter selection mode
- Click cards to toggle selection
- Use the selection bar to **Move**, **Export**, or **Delete** in bulk
- Press **Escape** or click **✕** to exit selection mode

---

## Updating & Managing Templates

### Update a Comp

If you've revised a comp and want to overwrite the saved template:

1. Select the updated comp in the AE Project panel
2. Open the card's **⋮ menu → Update Comp**
3. The template's comp, dimensions, duration, and preview are updated
4. Your custom name, tags, folder, and favorite status are preserved

### Recapture Preview

If the preview image looks wrong or is missing:

1. Open the card's **⋮ menu → Recapture Preview**
2. AE renders a new preview frame from the saved `.aep`

> This requires AE to run a silent render — it takes a few seconds and won't interrupt your work.

### Rename

- Open the card's **⋮ menu → Rename**, or **double-click the name text** on the card

### Delete

- Open the card's **⋮ menu → Delete** to permanently remove the template from the library

---

## Sharing Packs

Export one or more templates as a shareable folder that anyone can import.

**Export from toolbar:**
1. Click **⬆ Pack** in the toolbar
2. Name your pack and select which comps to include
3. Choose a destination folder
4. Share the exported folder with your team

**Export selected comps:**
1. Click **Select** → choose the comps you want
2. Click **Export** in the selection bar
3. Name your pack and choose a destination

---

## Installing Packs

To install a pack someone shared with you:

1. Click **⬇ Pack** in the toolbar
2. Select the pack folder
3. The comps are copied into your library (existing comps with the same slug are skipped)
4. A summary shows how many comps were installed

---

## Settings

Click the **gear icon** (top-right) to open Settings.

| Option | Description |
|---|---|
| **Library Folder** | Path to your comp library. All templates are stored here. |
| **Change** | Pick a different folder (useful for shared network drives) |
| **Open in Finder / Explorer** | Reveals the library folder in your file browser |

> Changing the library folder does not move existing templates — do that manually first if needed.

---

## Tips & Best Practices

**Naming**
- Give comps a clear, descriptive name before adding them to the library
- The display name can always be edited later without affecting the comp

**Project hygiene**
- Only save comps that are fully self-contained — remove unused footage and pre-comps before adding
- The plugin strips out unrelated items, but cleaner source = smaller template files

**Preview quality**
- The preview is captured 6 frames before the end of the comp
- If your comp has a black or empty last section, shorten its duration before capturing

**Shared libraries**
- Point your library folder to a shared network drive or synced cloud folder to share a live library with your team
- Everyone sees the same comps in real time

**Updating vs. re-adding**
- Use **Update Comp** instead of deleting and re-adding — it preserves your metadata

---

## Troubleshooting

**Panel doesn't appear in Window → Extensions**
- Make sure After Effects was fully restarted after installing the ZXP
- On macOS, check `~/Library/Application Support/Adobe/CEP/extensions/` — the `CompPacks` folder should be there

**Preview frame is blank or wrong**
- Use **⋮ → Recapture Preview** on the card
- Make sure the comp has visible content before the last 6 frames

**Inserted comp is named "comp" instead of the original name**
- This is a display folder from the AEP import — expand it in the Project panel to find the comp with the correct name

**Render Queue opens when inserting a comp**
- This can happen if the template was saved before a plugin update. Use **⋮ → Recapture Preview** on the affected card, then insert again

**Export Pack does nothing when clicked**
- If the modal doesn't open, try clicking **Select** first, selecting your comps, and using the Export button in the selection bar instead

**"File not found" on insert**
- The library folder may have moved. Go to **Settings → Change** and point it to the correct location

---

*CompPacks is developed and maintained by AI Video Lab.*
