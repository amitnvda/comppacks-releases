/* app.js — CompPack panel logic
   All file I/O goes through ExtendScript (cs.evalScript). No Node.js dependency.
*/

var cs     = new CSInterface();
var LS_KEY             = 'cp_library_folder';
var LS_FOLDER_KEY      = 'cp_active_folder';
var LS_STARTER_KEY     = 'cp_starter_dismissed'; // set after install or dismiss
var LS_SORT_KEY        = 'cp_sort_order';
var LS_DISMISS_KEY     = 'cp_update_dismissed';

// Node.js modules — available when CEP is launched with --enable-nodejs
var _fs    = typeof require !== 'undefined' ? require('fs')              : null;
var _path  = typeof require !== 'undefined' ? require('path')            : null;
var _os    = typeof require !== 'undefined' ? require('os')              : null;
var _child = typeof require !== 'undefined' ? require('child_process')   : null;

// Auto-update — multi-host fallback chain. Corporate networks (especially
// Windows) sometimes block one CDN via SmartScreen/proxy/AV. We try each
// host in order; first one that returns valid JSON wins.
//   1. raw.githubusercontent.com — canonical, always fresh
//   2. cdn.jsdelivr.net          — widely allowlisted CDN (may briefly cache)
//   3. api.github.com/contents   — REST API; always fresh, no CDN cache
var CP_LATEST_URLS = [
  'https://raw.githubusercontent.com/amitnvda/comppacks-releases/main/latest.json',
  'https://cdn.jsdelivr.net/gh/amitnvda/comppacks-releases@main/latest.json',
  'https://api.github.com/repos/amitnvda/comppacks-releases/contents/latest.json?ref=main'
];
var CP_DOWNLOAD_URL  = 'https://nvidia.sharepoint.com/:f:/r/sites/NBU-AcademyDM/R%20%20D/AE%20Plugins%20and%20Scripts/CompPacks?csf=1&web=1';
var CP_VERSION       = (function() {
  try {
    var manifestPath = (_path && _fs) ? _path.join(cs.getSystemPath(SystemPath.EXTENSION), 'CSXS', 'manifest.xml') : null;
    if (manifestPath) {
      var xml = _fs.readFileSync(manifestPath, 'utf8');
      var m = xml.match(/ExtensionBundleVersion="([^"]+)"/);
      if (m) return m[1];
    }
  } catch(_) {}
  return '0.0.0';
})();
var availableUpdateVersion = null;
var availableUpdateUrl     = null;
var _updZipPath            = null; // set when user drops a zip in the manual zone

var state = {
  libraryFolder: localStorage.getItem(LS_KEY) || '',
  templates:     [],
  folders:       [],  // user-created folder names (from _folders.json)
  activeFolder:  localStorage.getItem(LS_FOLDER_KEY) || 'all',
  sortOrder:     localStorage.getItem(LS_SORT_KEY)   || 'name-az',
  selectMode:    false,
  selected:      {}   // templateDir → template object
};

var _menuDropdown  = null;  // currently open card ⋯ dropdown
var _menuOutsideFn = null;  // outside-click handler reference

// Load a local image file using CEP's native fs API (no size limit, works cross-directory).
function setPreviewSrc(imgEl, previewPath) {
  if (!previewPath) return;
  if (window.cep && window.cep.fs) {
    var result = window.cep.fs.readFile(previewPath, 'base64');
    if (result.err === 0 && result.data) {
      var ext  = previewPath.split('.').pop().toLowerCase();
      var mime = (ext === 'jpg' || ext === 'jpeg') ? 'image/jpeg' : 'image/png';
      imgEl.src = 'data:' + mime + ';base64,' + result.data;
      return;
    }
  }
  // Fallback — some CEP versions support file:// within the same origin.
  // Windows paths (C:/...) need three slashes (file:///C:/...); Unix paths need two.
  var cleanPath = previewPath.replace(/\\/g, '/');
  imgEl.src = /^[A-Za-z]:/.test(cleanPath)
    ? 'file:///' + encodeURI(cleanPath)
    : 'file://'  + encodeURI(cleanPath);
}

// ── Boot ──────────────────────────────────────────────────────────────────

(function init() {
  wireUI();
  // Show installed version in the header badge
  var hv = document.getElementById('headerVersion');
  if (hv) hv.textContent = 'v' + CP_VERSION;

  if (state.libraryFolder) {
    ensureAndLoad();
  } else {
    cs.evalScript('clGetDefaultFolder()', function(res) {
      if (res && res.indexOf('OK:') === 0) {
        state.libraryFolder = res.replace('OK:', '').trim();
        localStorage.setItem(LS_KEY, state.libraryFolder);
      }
      ensureAndLoad();
    });
  }

  // Auto-update: silent check on boot, then every 30 min while panel is open.
  setTimeout(function() { cpCheckForUpdates(); }, 1500);
  setInterval(function() { cpCheckForUpdates(); }, 30 * 60 * 1000);
}());

function ensureAndLoad() {
  if (!state.libraryFolder) {
    renderSidebar();
    renderGrid([]);
    setStatus('No library folder set. Open Settings to configure.', 'info');
    return;
  }
  cs.evalScript('clEnsureFolder(' + JSON.stringify(state.libraryFolder) + ')', function() {
    loadFoldersThenTemplates();
  });
}

// ── Load folders → templates ──────────────────────────────────────────────

function loadFoldersThenTemplates() {
  cs.evalScript('clGetFolders(' + JSON.stringify(state.libraryFolder) + ')', function(res) {
    try {
      var data    = JSON.parse(res);
      state.folders = (data.ok && data.folders) ? data.folders : [];
    } catch (_) { state.folders = []; }
    loadAndRenderTemplates();
  });
}

function loadAndRenderTemplates() {
  if (!state.libraryFolder) { renderSidebar(); renderGrid([]); return; }
  showProgress(true);

  cs.evalScript('clListTemplates(' + JSON.stringify(state.libraryFolder) + ')', function(res) {
    showProgress(false);
    var data;
    try { data = JSON.parse(res); } catch (_) { data = { ok: false }; }
    state.templates = (data.ok && data.templates) ? data.templates : [];

    // Normalise fields that may be absent in older meta.json files
    state.templates.forEach(function(t) {
      t.folder  = t.folder  || '';
      t.starred = !!t.starred;
    });

    // Merge any folder names found in templates but missing from _folders.json
    state.templates.forEach(function(t) {
      if (t.folder && state.folders.indexOf(t.folder) < 0) {
        state.folders.push(t.folder);
      }
    });
    state.folders.sort();

    // Validate active folder still exists; fall back to 'all'
    // (also rescues legacy 'recent' selection now that the view is gone)
    if (state.activeFolder === 'recent') {
      state.activeFolder = 'all';
      localStorage.setItem(LS_FOLDER_KEY, 'all');
    } else if (state.activeFolder !== 'all' && state.activeFolder !== 'favorites') {
      if (state.folders.indexOf(state.activeFolder) < 0) {
        state.activeFolder = 'all';
        localStorage.setItem(LS_FOLDER_KEY, 'all');
      }
    }

    renderSidebar();
    renderGrid(getFilteredTemplates());
    updateStatusCount();
    checkStarterBanner();
  });
}

// ── Sidebar ───────────────────────────────────────────────────────────────

function renderSidebar() {
  var allCount    = state.templates.length;
  var favCount    = state.templates.filter(function(t) { return t.starred; }).length;

  document.getElementById('sidebarAllCount').textContent  = allCount || '';
  document.getElementById('sidebarFavsCount').textContent = favCount || '';

  // Highlight fixed items
  document.getElementById('folderAll').classList.toggle('active',  state.activeFolder === 'all');
  document.getElementById('folderFavs').classList.toggle('active', state.activeFolder === 'favorites');

  // Render user folders
  var list = document.getElementById('sidebarFolderList');
  list.innerHTML = '';

  state.folders.forEach(function(folderName) {
    var count = state.templates.filter(function(t) { return t.folder === folderName; }).length;

    var item = document.createElement('div');
    item.className      = 'sidebar-item' + (state.activeFolder === folderName ? ' active' : '');
    item.dataset.folder = folderName;
    item.innerHTML =
      '<span class="sidebar-item-icon">&#128193;</span>' +
      '<span class="sidebar-item-label" title="' + escAttr(folderName) + '">' + escHtml(folderName) + '</span>' +
      (count ? '<span class="sidebar-item-count">' + count + '</span>' : '') +
      '<button class="sidebar-item-delete" title="Delete folder">&#215;</button>';

    // Click → select folder
    item.addEventListener('click', function(e) {
      if (e.target.classList.contains('sidebar-item-delete')) return;
      closeCardMenu();
      setActiveFolder(folderName);
    });

    // Double-click label → rename
    item.querySelector('.sidebar-item-label').addEventListener('dblclick', function(e) {
      e.stopPropagation();
      var newName = prompt('Rename folder:', folderName);
      if (newName && newName.trim() && newName.trim() !== folderName) {
        renameFolder(folderName, newName.trim());
      }
    });

    // Delete button
    item.querySelector('.sidebar-item-delete').addEventListener('click', function(e) {
      e.stopPropagation();
      deleteFolder(folderName);
    });

    list.appendChild(item);
  });
}

function setActiveFolder(name) {
  state.activeFolder = name;
  localStorage.setItem(LS_FOLDER_KEY, name);
  renderSidebar();
  renderGrid(getFilteredTemplates());
  updateStatusCount();
}

// ── Filtering + sorting ───────────────────────────────────────────────────

function sortPool(pool) {
  var order = state.sortOrder;
  return pool.slice().sort(function(a, b) {
    if (order === 'name-az') return (a.name || '').localeCompare(b.name || '');
    if (order === 'name-za') return (b.name || '').localeCompare(a.name || '');
    if (order === 'newest')  return (b.addedAt || '') > (a.addedAt || '') ? 1 : -1;
    if (order === 'oldest')  return (a.addedAt || '') > (b.addedAt || '') ? 1 : -1;
    return 0;
  });
}

function getFilteredTemplates() {
  var q = document.getElementById('searchInput').value.toLowerCase().trim();
  var pool;

  pool = state.templates.filter(function(t) {
    if (state.activeFolder === 'all')       return true;
    if (state.activeFolder === 'favorites') return t.starred;
    return t.folder === state.activeFolder;
  });
  pool = sortPool(pool);

  if (!q) return pool;
  return pool.filter(function(t) {
    return (t.name || '').toLowerCase().indexOf(q) >= 0 ||
           (t.tags || []).join(' ').toLowerCase().indexOf(q) >= 0;
  });
}

// ── Render grid ───────────────────────────────────────────────────────────

function renderGrid(templates) {
  closeCardMenu();
  var grid = document.getElementById('templateGrid');
  grid.innerHTML = '';
  grid.classList.toggle('select-mode', state.selectMode);

  if (!templates || templates.length === 0) {
    var empty = document.createElement('div');
    empty.className = 'empty-state';
    var title, sub;
    if (state.activeFolder === 'favorites') {
      title = 'No favorites yet';
      sub   = 'Click \u2605 on a comp card to add it here.';
    } else if (state.activeFolder !== 'all') {
      title = 'Folder is empty';
      sub   = 'Use \u22ef on any comp card to move it here.';
    } else {
      title = 'No comps yet';
      sub   = 'Select a comp in AE\'s Project panel,<br>then click <strong>+ Add to CompPack</strong>';
    }
    empty.innerHTML =
      '<div class="empty-state-icon">&#128450;</div>' +
      '<div class="empty-state-title">' + title + '</div>' +
      '<div class="empty-state-sub">' + sub + '</div>';
    grid.appendChild(empty);
    return;
  }

  for (var i = 0; i < templates.length; i++) {
    var card = buildCard(templates[i]);
    if (state.selected[templates[i].templateDir]) card.classList.add('selected');
    grid.appendChild(card);
  }
}

function buildCard(t) {
  var card = document.createElement('div');
  card.className           = 'template-card';
  card.dataset.name        = (t.name || '').toLowerCase();
  card.dataset.tags        = (t.tags || []).join(' ').toLowerCase();
  card.dataset.aepPath     = t.aepPath;
  card.dataset.compName    = t.compName || '';
  card.dataset.templateDir = t.templateDir;

  // ── 16:9 preview area ─────────────────────────────────────
  var preview = document.createElement('div');
  preview.className = 'template-preview';

  if (t.previewPath) {
    var img = document.createElement('img');
    img.alt = t.name || '';
    setPreviewSrc(img, t.previewPath);
    img.onerror = function() {
      this.style.display = 'none';
      var ph = document.createElement('div');
      ph.className   = 'template-preview-placeholder';
      ph.textContent = t.name || '';
      preview.insertBefore(ph, preview.firstChild);
    };
    preview.appendChild(img);
  } else {
    var ph = document.createElement('div');
    ph.className   = 'template-preview-placeholder';
    ph.textContent = t.name || '';
    preview.appendChild(ph);
  }

  // Build metadata string here, render below name in info section (cleaner thumbnail)
  var metaText = '';
  if (t.width && t.height) {
    var durStr = t.duration ? formatDuration(t.duration) : '';
    metaText = t.width + '\u00d7' + t.height +
               (t.frameRate ? ' \u00b7 ' + t.frameRate + 'fps' : '') +
               (durStr      ? ' \u00b7 ' + durStr : '');
  }

  // ── Select indicator (top-left, shown in select mode) ─────
  var selectIndicator = document.createElement('div');
  selectIndicator.className = 'card-select-indicator';
  preview.appendChild(selectIndicator);

  // ── Star button (top-left) ────────────────────────────────
  var starBtn = document.createElement('button');
  starBtn.className = 'card-star-btn' + (t.starred ? ' starred' : '');
  starBtn.title     = t.starred ? 'Remove from Favorites' : 'Add to Favorites';
  starBtn.innerHTML = '&#9733;';
  starBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    toggleStar(t, starBtn, card);
  });
  preview.appendChild(starBtn);

  // ── Menu button (top-right) ───────────────────────────────
  var menuBtn = document.createElement('button');
  menuBtn.className = 'card-menu-btn';
  menuBtn.title     = 'Options';
  menuBtn.innerHTML = '&#8943;'; // ⋯
  menuBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    openCardMenu(menuBtn, t, card);
  });
  preview.appendChild(menuBtn);

  // ── Hover overlay (Insert button) ─────────────────────────
  var overlay = document.createElement('div');
  overlay.className = 'template-overlay';
  var insertBtn = document.createElement('button');
  insertBtn.className   = 'template-import-btn';
  insertBtn.textContent = 'Insert';
  insertBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    insertComp(t.aepPath, t.compName, t.name, t.templateDir, card);
  });
  overlay.appendChild(insertBtn);
  preview.appendChild(overlay);

  card.appendChild(preview);

  // ── Name + tags ───────────────────────────────────────────
  var info = document.createElement('div');
  info.className = 'template-info';

  var nameEl = document.createElement('div');
  nameEl.className   = 'template-name';
  nameEl.textContent = t.name || 'Untitled';
  nameEl.title       = 'Double-click to rename';
  nameEl.addEventListener('dblclick', function(e) {
    e.stopPropagation();
    var newName = prompt('Rename comp:', t.name);
    if (newName && newName.trim() && newName.trim() !== t.name) renameComp(t, newName.trim(), card);
  });
  info.appendChild(nameEl);

  if (metaText) {
    var metaEl = document.createElement('div');
    metaEl.className   = 'template-meta';
    metaEl.textContent = metaText;
    info.appendChild(metaEl);
  }

  if (t.tags && t.tags.length) {
    var tagsEl = document.createElement('div');
    tagsEl.className = 'template-tags';
    t.tags.forEach(function(tag) {
      var chip = document.createElement('span');
      chip.className   = 'tag-chip';
      chip.textContent = tag;
      tagsEl.appendChild(chip);
    });
    info.appendChild(tagsEl);
  }

  card.appendChild(info);

  // Single click → toggle selection in select mode only
  card.addEventListener('click', function() {
    if (state.selectMode) { toggleCardSelection(t, card); }
  });

  // Double-click card → insert
  card.addEventListener('dblclick', function() {
    if (state.selectMode) return;
    insertComp(t.aepPath, t.compName, t.name, t.templateDir, card);
  });

  return card;
}

// ── Star toggle ───────────────────────────────────────────────────────────

function toggleStar(t, starBtn, card) {
  var newVal = !t.starred;
  var patch  = JSON.stringify({ starred: newVal });

  cs.evalScript(
    'clUpdateMeta(' + JSON.stringify(t.templateDir) + ',' + JSON.stringify(patch) + ')',
    function(res) {
      if (res && res.indexOf('ERROR:') === 0) {
        setStatus(res.replace('ERROR:', '').trim(), 'error'); return;
      }
      t.starred     = newVal;
      starBtn.className = 'card-star-btn' + (newVal ? ' starred' : '');
      starBtn.title     = newVal ? 'Remove from Favorites' : 'Add to Favorites';

      // If in Favorites view and we just unstarred, remove the card
      if (state.activeFolder === 'favorites' && !newVal) {
        card.remove();
        if (!document.querySelector('.template-card')) renderGrid([]);
      }

      // Update sidebar favorites count
      var favCount = state.templates.filter(function(x) { return x.starred; }).length;
      document.getElementById('sidebarFavsCount').textContent = favCount || '';
    }
  );
}

// ── Card menu (⋯ dropdown) ────────────────────────────────────────────────

function openCardMenu(btn, t, card) {
  closeCardMenu();

  var menu = document.createElement('div');
  menu.className = 'card-menu-dropdown';

  // ── Move to section ──────────────────────────────────────
  if (state.folders.length > 0) {
    var sectionTitle = document.createElement('div');
    sectionTitle.className   = 'menu-section-title';
    sectionTitle.textContent = 'Move to';
    menu.appendChild(sectionTitle);

    state.folders.forEach(function(folderName) {
      var item = document.createElement('div');
      item.className = 'menu-item' + (t.folder === folderName ? ' active-folder' : '');
      item.innerHTML = '&#128193; ' + escHtml(folderName);
      item.addEventListener('click', function() {
        closeCardMenu(); moveToFolder(t, folderName, card);
      });
      menu.appendChild(item);
    });
  }

  // New folder
  var newFolderItem = document.createElement('div');
  newFolderItem.className   = 'menu-item';
  newFolderItem.textContent = '+ New folder\u2026';
  newFolderItem.addEventListener('click', function() {
    closeCardMenu();
    var name = prompt('New folder name:');
    if (!name || !name.trim()) return;
    name = name.trim();
    createFolder(name, function() { moveToFolder(t, name, card); });
  });
  menu.appendChild(newFolderItem);

  // Remove from folder
  if (t.folder) {
    var removeItem = document.createElement('div');
    removeItem.className   = 'menu-item';
    removeItem.textContent = 'Remove from folder';
    removeItem.addEventListener('click', function() {
      closeCardMenu(); moveToFolder(t, '', card);
    });
    menu.appendChild(removeItem);
  }

  // ── Edit section ─────────────────────────────────────
  var editDivider = document.createElement('div');
  editDivider.className = 'menu-divider';
  menu.appendChild(editDivider);

  var renameItem = document.createElement('div');
  renameItem.className   = 'menu-item';
  renameItem.textContent = 'Rename\u2026';
  renameItem.addEventListener('click', function() {
    closeCardMenu();
    var newName = prompt('Rename comp:', t.name);
    if (newName && newName.trim() && newName.trim() !== t.name) renameComp(t, newName.trim(), card);
  });
  menu.appendChild(renameItem);

  var tagsItem = document.createElement('div');
  tagsItem.className   = 'menu-item';
  tagsItem.textContent = 'Edit tags\u2026';
  tagsItem.addEventListener('click', function() {
    closeCardMenu();
    var current   = (t.tags || []).join(', ');
    var newTagsStr = prompt('Tags (comma-separated):', current);
    if (newTagsStr === null) return;
    var newTags = newTagsStr.split(',').map(function(s) { return s.trim(); }).filter(Boolean);
    editTags(t, newTags, card);
  });
  menu.appendChild(tagsItem);

  var updateItem = document.createElement('div');
  updateItem.className   = 'menu-item';
  updateItem.textContent = 'Update comp\u2026';
  updateItem.addEventListener('click', function() {
    closeCardMenu(); updateComp(t, card);
  });
  menu.appendChild(updateItem);

  var recaptureItem = document.createElement('div');
  recaptureItem.className   = 'menu-item';
  recaptureItem.textContent = 'Re-capture preview';
  recaptureItem.addEventListener('click', function() {
    closeCardMenu(); recapturePreview(t, card);
  });
  menu.appendChild(recaptureItem);

  // Divider + delete
  var divider = document.createElement('div');
  divider.className = 'menu-divider';
  menu.appendChild(divider);

  var deleteItem = document.createElement('div');
  deleteItem.className   = 'menu-item menu-danger';
  deleteItem.textContent = 'Delete\u2026';
  deleteItem.addEventListener('click', function() {
    closeCardMenu(); deleteComp(t.templateDir, t.name, card);
  });
  menu.appendChild(deleteItem);

  document.body.appendChild(menu);
  _menuDropdown = menu;

  // Position below/beside the button
  var rect  = btn.getBoundingClientRect();
  var menuW = 168;
  var left  = Math.min(rect.right - menuW, window.innerWidth - menuW - 8);
  menu.style.left = Math.max(8, left) + 'px';
  menu.style.top  = (rect.bottom + 4) + 'px';

  // Dismiss on outside click
  setTimeout(function() {
    _menuOutsideFn = function() { closeCardMenu(); };
    document.addEventListener('click', _menuOutsideFn);
  }, 0);
}

function closeCardMenu() {
  if (_menuOutsideFn) {
    document.removeEventListener('click', _menuOutsideFn);
    _menuOutsideFn = null;
  }
  if (_menuDropdown && _menuDropdown.parentNode) {
    _menuDropdown.parentNode.removeChild(_menuDropdown);
  }
  _menuDropdown = null;
}

// ── Move to folder ────────────────────────────────────────────────────────

function moveToFolder(t, folderName, card) {
  var patch = JSON.stringify({ folder: folderName });
  cs.evalScript(
    'clUpdateMeta(' + JSON.stringify(t.templateDir) + ',' + JSON.stringify(patch) + ')',
    function(res) {
      if (res && res.indexOf('ERROR:') === 0) {
        setStatus(res.replace('ERROR:', '').trim(), 'error'); return;
      }
      t.folder = folderName;

      // If viewing a specific folder and this comp no longer belongs, remove it
      if (state.activeFolder !== 'all' && state.activeFolder !== 'favorites') {
        if (t.folder !== state.activeFolder) {
          card.remove();
          if (!document.querySelector('.template-card')) renderGrid([]);
        }
      }

      renderSidebar();
    }
  );
}

// ── Folder management ─────────────────────────────────────────────────────

function createFolder(name, callback) {
  if (state.folders.indexOf(name) >= 0) { if (callback) callback(); return; }
  state.folders.push(name);
  state.folders.sort();
  var foldersJSON = JSON.stringify(state.folders);
  cs.evalScript(
    'clSaveFolders(' + JSON.stringify(state.libraryFolder) + ',' + JSON.stringify(foldersJSON) + ')',
    function() { renderSidebar(); if (callback) callback(); }
  );
}

function renameFolder(oldName, newName) {
  if (!newName) return;
  if (state.folders.indexOf(newName) >= 0) {
    setStatus('A folder named \u201c' + newName + '\u201d already exists.', 'error');
    setTimeout(function() { setStatus('', ''); }, 3000);
    return;
  }
  showProgress(true);
  cs.evalScript(
    'clRenameFolder(' + JSON.stringify(state.libraryFolder) + ',' +
    JSON.stringify(oldName) + ',' + JSON.stringify(newName) + ')',
    function(res) {
      showProgress(false);
      if (res && res.indexOf('ERROR:') === 0) {
        setStatus(res.replace('ERROR:', '').trim(), 'error'); return;
      }
      var idx = state.folders.indexOf(oldName);
      if (idx >= 0) state.folders[idx] = newName;
      state.folders.sort();
      state.templates.forEach(function(t) { if (t.folder === oldName) t.folder = newName; });
      if (state.activeFolder === oldName) {
        state.activeFolder = newName;
        localStorage.setItem(LS_FOLDER_KEY, newName);
      }
      renderSidebar();
      renderGrid(getFilteredTemplates());
    }
  );
}

function deleteFolder(name) {
  var count = state.templates.filter(function(t) { return t.folder === name; }).length;
  var msg   = 'Delete folder \u201c' + name + '\u201d?' +
              (count > 0 ? '\n\n' + count + ' comp(s) will be moved to All Comps.' : '');
  if (!confirm(msg)) return;

  showProgress(true);

  var toUpdate = state.templates.filter(function(t) { return t.folder === name; });
  var pending  = toUpdate.length;

  function finish() {
    state.folders = state.folders.filter(function(f) { return f !== name; });
    cs.evalScript(
      'clSaveFolders(' + JSON.stringify(state.libraryFolder) + ',' +
      JSON.stringify(JSON.stringify(state.folders)) + ')',
      function() {
        showProgress(false);
        if (state.activeFolder === name) {
          state.activeFolder = 'all';
          localStorage.setItem(LS_FOLDER_KEY, 'all');
        }
        renderSidebar();
        renderGrid(getFilteredTemplates());
      }
    );
  }

  if (pending === 0) { finish(); return; }

  toUpdate.forEach(function(t) {
    t.folder = '';
    cs.evalScript(
      'clUpdateMeta(' + JSON.stringify(t.templateDir) + ',' + JSON.stringify('{"folder":""}') + ')',
      function() { if (--pending === 0) finish(); }
    );
  });
}

// ── Add selected comp ─────────────────────────────────────────────────────

function addSelectedComp() {
  if (!state.libraryFolder) {
    setStatus('Configure a library folder in Settings first.', 'error'); return;
  }
  setStatus('Saving comp \u2014 project will briefly reload\u2026', 'info');
  showProgress(true);

  cs.evalScript('clAddSelectedComp(' + JSON.stringify(state.libraryFolder) + ')', function(res) {
    showProgress(false);
    if (!res || res === 'EvalScript error.') {
      setStatus('Script error \u2014 restart AE and try again.', 'error');
      // Files may have been written before the error — refresh anyway
      setTimeout(function() { loadAndRenderTemplates(); }, 600);
      return;
    }
    if (res.indexOf('ERROR:') === 0) {
      setStatus(res.replace('ERROR:', '').trim(), 'error');
      // Files may have been written before app.open() threw — refresh anyway
      setTimeout(function() { loadAndRenderTemplates(); }, 600);
      return;
    }
    var noPreview = res.indexOf('OK_NOPREVIEW:') === 0;
    var compName  = res.replace(/^OK(_NOPREVIEW)?:/, '');
    var msg = '\u2713 \u201c' + compName + '\u201d added to CompPack';
    if (noPreview) msg += ' \u2014 preview unavailable';
    setStatus(msg, 'success');
    setTimeout(function() { setStatus('', ''); }, 4000);
    // Small delay — gives AE time to finish opening the restored project on Windows
    setTimeout(function() { loadAndRenderTemplates(); }, 400);
  });
}

// ── Insert comp into current project + active timeline ────────────────────

function insertComp(aepPath, compName, displayName, templateDir, cardEl) {
  if (!aepPath) { setStatus('No path for this comp.', 'error'); return; }
  setStatus('Inserting\u2026', 'info');
  showProgress(true);

  cs.evalScript(
    'clInsertComp(' + JSON.stringify(aepPath) + ',' + JSON.stringify(compName || '') + ',' + JSON.stringify(displayName || compName || '') + ')',
    function(res) {
      showProgress(false);
      if (!res || res === 'EvalScript error.') {
        setStatus('Script error \u2014 check AE console.', 'error'); return;
      }
      if (res.indexOf('ERROR:') === 0) {
        setStatus(res.replace('ERROR:', '').trim(), 'error'); return;
      }
      // Parse: "OK:<name>" or "OK:<name>|PREVIEW:<path>"
      var okPart = res.replace('OK:', '');
      var previewPath = null;
      var pipIdx = okPart.indexOf('|PREVIEW:');
      if (pipIdx >= 0) {
        previewPath = okPart.slice(pipIdx + 9);
        okPart = okPart.slice(0, pipIdx);
      }
      var name = okPart.trim();
      setStatus('\u2713 \u201c' + (displayName || name) + '\u201d inserted', 'success');
      setTimeout(function() { setStatus('', ''); }, 3000);

      // Update thumbnail if we got a fresh preview
      if (previewPath && cardEl) {
        var img = cardEl.querySelector('.template-preview img');
        if (img) {
          img.src = '';
          setPreviewSrc(img, previewPath);
        } else {
          var preview = cardEl.querySelector('.template-preview');
          if (preview) {
            var ph = preview.querySelector('.template-preview-placeholder');
            if (ph) ph.style.display = 'none';
            var newImg = document.createElement('img');
            newImg.alt = displayName || name;
            preview.insertBefore(newImg, preview.firstChild);
            setPreviewSrc(newImg, previewPath);
          }
        }
      }
    }
  );
}

// ── Delete comp from library ──────────────────────────────────────────────

function deleteComp(templateDir, name, cardEl) {
  if (!confirm('Remove \u201c' + name + '\u201d from CompPack?\n\nThis deletes the template files and cannot be undone.')) return;

  cs.evalScript('clDeleteTemplate(' + JSON.stringify(templateDir) + ')', function(res) {
    if (res && res.indexOf('ERROR:') === 0) {
      setStatus('Delete failed: ' + res.replace('ERROR:', '').trim(), 'error'); return;
    }
    cardEl.remove();
    state.templates = state.templates.filter(function(t) { return t.templateDir !== templateDir; });
    if (!document.querySelector('.template-card')) renderGrid([]);
    renderSidebar();
    setStatus('\u201c' + name + '\u201d removed from library', 'info');
    setTimeout(function() { setStatus('', ''); }, 2500);
  });
}


// ── Rename comp ───────────────────────────────────────────────────────────

function renameComp(t, newName, card) {
  var patch = JSON.stringify({ name: newName });
  cs.evalScript(
    'clUpdateMeta(' + JSON.stringify(t.templateDir) + ',' + JSON.stringify(patch) + ')',
    function(res) {
      if (res && res.indexOf('ERROR:') === 0) { setStatus(res.replace('ERROR:', '').trim(), 'error'); return; }
      t.name = newName;
      var nameEl = card.querySelector('.template-name');
      if (nameEl) nameEl.textContent = newName;
    }
  );
}

// ── Edit tags ─────────────────────────────────────────────────────────────

function editTags(t, newTags, card) {
  var patch = JSON.stringify({ tags: newTags });
  cs.evalScript(
    'clUpdateMeta(' + JSON.stringify(t.templateDir) + ',' + JSON.stringify(patch) + ')',
    function(res) {
      if (res && res.indexOf('ERROR:') === 0) { setStatus(res.replace('ERROR:', '').trim(), 'error'); return; }
      t.tags = newTags;
      card.dataset.tags = newTags.join(' ').toLowerCase();
    }
  );
}

// ── Update comp ───────────────────────────────────────────────────────────

function updateComp(t, card) {
  if (!confirm(
    'Update \u201c' + t.name + '\u201d?\n\n' +
    'The selected comp in AE will replace the stored .aep and the preview will be re-captured.'
  )) return;

  setStatus('Updating comp \u2014 project will briefly reload\u2026', 'info');
  showProgress(true);

  cs.evalScript('clUpdateComp(' + JSON.stringify(t.templateDir) + ')', function(res) {
    showProgress(false);
    if (!res || res === 'EvalScript error.') {
      setStatus('Script error \u2014 restart AE and try again.', 'error'); return;
    }
    if (res.indexOf('ERROR:') === 0) {
      setStatus(res.replace('ERROR:', '').trim(), 'error'); return;
    }
    var noPreview = res.indexOf('OK_NOPREVIEW:') === 0;
    var msg = '\u2713 \u201c' + escHtml(t.name || '') + '\u201d updated';
    if (noPreview) msg += ' \u2014 preview unavailable';
    setStatus(msg, 'success');
    setTimeout(function() { setStatus('', ''); }, 3000);
    loadAndRenderTemplates(); // full refresh — new preview + updated technical fields
  });
}

// ── Export Pack modal ─────────────────────────────────────────────────────

function openExportModal(preSelectedDirs) {
  if (state.templates.length === 0) {
    setStatus('No comps in library to export.', 'error'); return;
  }

  // Populate comp list (sorted A→Z)
  var list = document.getElementById('exportCompList');
  list.innerHTML = '';
  var sorted = state.templates.slice().sort(function(a, b) {
    return (a.name || '').localeCompare(b.name || '');
  });
  sorted.forEach(function(t) {
    var row = document.createElement('label');
    row.className = 'modal-comp-item';

    var cb = document.createElement('input');
    cb.type    = 'checkbox';
    cb.checked = !preSelectedDirs || preSelectedDirs.indexOf(t.templateDir) >= 0;
    cb.dataset.templateDir = t.templateDir;

    var nameSpan = document.createElement('span');
    nameSpan.textContent = t.name || t.id || 'Untitled';

    row.appendChild(cb);
    row.appendChild(nameSpan);

    if (t.folder) {
      var folderSpan = document.createElement('span');
      folderSpan.className   = 'modal-comp-folder';
      folderSpan.textContent = t.folder;
      row.appendChild(folderSpan);
    }

    list.appendChild(row);
  });

  document.getElementById('exportPackName').value = 'My CompPack';
  document.getElementById('exportModal').style.display = 'flex';
}

function closeExportModal() {
  document.getElementById('exportModal').style.display = 'none';
}

function doExport() {
  var packName = (document.getElementById('exportPackName').value || '').trim();
  if (!packName) { document.getElementById('exportPackName').focus(); return; }

  var checked = document.querySelectorAll('#exportCompList input[type="checkbox"]:checked');
  if (checked.length === 0) {
    setStatus('Select at least one comp to export.', 'error'); return;
  }

  var dirs = [];
  for (var i = 0; i < checked.length; i++) {
    dirs.push(checked[i].dataset.templateDir);
  }

  closeExportModal();

  setStatus('Choose a destination folder in the dialog\u2026', 'info');
  cs.evalScript('clSelectFolder()', function(res) {
    if (!res || res === 'CANCELLED') { setStatus('', ''); return; }
    if (res.indexOf('ERROR:') === 0) {
      setStatus(res.replace('ERROR:', '').trim(), 'error'); return;
    }
    var parentDir = res.replace('OK:', '').trim();

    showProgress(true);
    setStatus('Exporting pack\u2026', 'info');

    cs.evalScript(
      'clExportPack(' + JSON.stringify(JSON.stringify(dirs)) + ',' +
      JSON.stringify(packName) + ',' + JSON.stringify(parentDir) + ')',
      function(res2) {
        showProgress(false);
        if (!res2 || res2 === 'EvalScript error.') {
          setStatus('Script error \u2014 restart AE and try again.', 'error'); return;
        }
        if (res2.indexOf('ERROR:') === 0) {
          setStatus(res2.replace('ERROR:', '').trim(), 'error'); return;
        }
        var packPath = res2.replace('OK:', '').trim();
        var packFolderName = packPath.split('/').pop();
        setStatus('\u2713 Pack \u201c' + packFolderName + '\u201d exported with ' + dirs.length +
                  ' comp' + (dirs.length === 1 ? '' : 's'), 'success');
        setTimeout(function() { setStatus('', ''); }, 5000);
      }
    );
  });
}

// ── Re-capture preview ────────────────────────────────────────────────────

function recapturePreview(t, card) {
  setStatus('Re-capturing preview \u2014 project will briefly reload\u2026', 'info');
  showProgress(true);

  cs.evalScript(
    'clRecapturePreview(' + JSON.stringify(t.aepPath) + ',' + JSON.stringify(t.templateDir) + ')',
    function(res) {
      showProgress(false);
      if (!res || res === 'EvalScript error.') {
        setStatus('Script error \u2014 restart AE and try again.', 'error'); return;
      }
      if (res.indexOf('ERROR:') === 0) {
        setStatus(res.replace('ERROR:', '').trim(), 'error'); return;
      }
      var newPath = res.replace('OK:', '').trim();
      t.previewPath = newPath;
      setStatus('\u2713 Preview updated for \u201c' + escHtml(t.name || '') + '\u201d', 'success');
      setTimeout(function() { setStatus('', ''); }, 3000);
      // Full reload — browser caches file:// URLs by path, so rebuilding cards is the only safe way
      loadAndRenderTemplates();
    }
  );
}

// ── Starter pack banner ───────────────────────────────────────────────────

function checkStarterBanner() {
  // Only show if not already dismissed/installed, and library is empty
  if (localStorage.getItem(LS_STARTER_KEY)) return;
  if (state.templates.length > 0) return;

  cs.evalScript('clCheckStarterPack()', function(res) {
    var data;
    try { data = JSON.parse(res); } catch (_) { return; }
    if (!data || !data.ok || !data.count) return;

    var banner = document.getElementById('starterBanner');
    document.getElementById('starterBannerMsg').textContent =
      '\u{1F4E6} Starter pack available \u2014 ' + data.count + ' comp' + (data.count === 1 ? '' : 's');
    banner._packDir = data.packDir;
    banner.style.display = 'flex';
  });
}

function installStarterPack() {
  var banner  = document.getElementById('starterBanner');
  var packDir = banner._packDir;
  if (!packDir) return;

  banner.style.display = 'none';
  showProgress(true);
  setStatus('Installing starter pack\u2026', 'info');

  cs.evalScript(
    'clInstallPackFrom(' + JSON.stringify(packDir) + ',' + JSON.stringify(state.libraryFolder) + ')',
    function(res) {
      showProgress(false);
      var data;
      try { data = JSON.parse(res); } catch (_) { data = { ok: false }; }
      if (!data.ok) {
        setStatus('Install failed: ' + (data.error || 'unknown error'), 'error'); return;
      }
      localStorage.setItem(LS_STARTER_KEY, '1');
      var msg = '\u2713 Installed ' + data.installed + ' comp' + (data.installed === 1 ? '' : 's');
      if (data.skipped > 0) msg += ' (' + data.skipped + ' skipped)';
      setStatus(msg, 'success');
      setTimeout(function() { setStatus('', ''); }, 4000);
      loadFoldersThenTemplates();
    }
  );
}

function dismissStarterBanner() {
  document.getElementById('starterBanner').style.display = 'none';
  localStorage.setItem(LS_STARTER_KEY, '1');
}

// ── Import pack from folder ───────────────────────────────────────────────

function importPack() {
  if (!state.libraryFolder) {
    setStatus('Configure a library folder in Settings first.', 'error'); return;
  }
  cs.evalScript('clSelectFolder()', function(res) {
    if (!res || res === 'CANCELLED' || res.indexOf('ERROR:') === 0) return;
    var packDir = res.replace('OK:', '').trim();
    showProgress(true);
    setStatus('Importing pack\u2026', 'info');

    cs.evalScript(
      'clInstallPackFrom(' + JSON.stringify(packDir) + ',' + JSON.stringify(state.libraryFolder) + ')',
      function(res2) {
        showProgress(false);
        var data;
        try { data = JSON.parse(res2); } catch (_) { data = { ok: false }; }
        if (!data.ok) {
          setStatus('Import failed: ' + (data.error || 'unknown error'), 'error'); return;
        }
        if (data.installed === 0 && data.skipped === 0) {
          setStatus('No valid comps found in that folder.', 'error'); return;
        }
        var msg = '\u2713 Imported ' + data.installed + ' comp' + (data.installed === 1 ? '' : 's');
        if (data.skipped > 0) msg += ' \u2014 ' + data.skipped + ' already existed (skipped)';
        setStatus(msg, 'success');
        setTimeout(function() { setStatus('', ''); }, 4000);
        loadFoldersThenTemplates();
      }
    );
  });
}

// ── Settings ──────────────────────────────────────────────────────────────

function openSettings() {
  var el = document.getElementById('settingsFolderPath');
  el.textContent = state.libraryFolder || '(not set)';
  el.title       = state.libraryFolder || '';
  document.getElementById('settingsInfo').textContent =
    state.templates.length + ' comp' + (state.templates.length === 1 ? '' : 's') + ' in library';
  document.getElementById('settingsOverlay').classList.add('visible');
  document.getElementById('settingsBtn').classList.add('active');
}

function closeSettings() {
  document.getElementById('settingsOverlay').classList.remove('visible');
  document.getElementById('settingsBtn').classList.remove('active');
}

function changeLibraryFolder() {
  cs.evalScript('clSelectFolder()', function(res) {
    if (!res || res === 'CANCELLED' || res.indexOf('ERROR:') === 0) return;
    state.libraryFolder = res.replace('OK:', '').trim();
    localStorage.setItem(LS_KEY, state.libraryFolder);
    closeSettings();
    ensureAndLoad();
  });
}

function openLibraryInFinder() {
  if (state.libraryFolder) cs.openURLInDefaultBrowser('file://' + encodeURI(state.libraryFolder));
}

// ── Multi-select ──────────────────────────────────────────────────────────

function enterSelectMode() {
  state.selectMode = true;
  state.selected   = {};
  document.getElementById('templateGrid').classList.add('select-mode');
  document.getElementById('selectModeBtn').classList.add('active');
  document.getElementById('selectionBar').style.display = 'flex';
  document.querySelector('.status-bar').style.display   = 'none';
  updateSelectionBar();
}

function exitSelectMode() {
  state.selectMode = false;
  state.selected   = {};
  document.querySelectorAll('.template-card.selected').forEach(function(c) {
    c.classList.remove('selected');
  });
  document.getElementById('templateGrid').classList.remove('select-mode');
  document.getElementById('selectModeBtn').classList.remove('active');
  document.getElementById('selectionBar').style.display = 'none';
  document.querySelector('.status-bar').style.display   = '';
}

function toggleCardSelection(t, card) {
  if (state.selected[t.templateDir]) {
    delete state.selected[t.templateDir];
    card.classList.remove('selected');
  } else {
    state.selected[t.templateDir] = t;
    card.classList.add('selected');
  }
  updateSelectionBar();
}

function updateSelectionBar() {
  var count = Object.keys(state.selected).length;
  document.getElementById('selectionCount').textContent =
    count === 0 ? 'Click comps to select' : count + ' selected';
  var show = count > 0 ? '' : 'none';
  document.getElementById('selMoveBtn').style.display   = show;
  document.getElementById('selExportBtn').style.display = show;
  document.getElementById('selDeleteBtn').style.display = show;
}

function bulkDelete() {
  var dirs = Object.keys(state.selected);
  if (dirs.length === 0) return;
  if (!confirm('Delete ' + dirs.length + ' comp' + (dirs.length === 1 ? '' : 's') + '?\n\nThis cannot be undone.')) return;

  var toDelete = dirs.slice();
  exitSelectMode();
  showProgress(true);
  setStatus('Deleting ' + toDelete.length + ' comp(s)\u2026', 'info');

  var pending = toDelete.length;
  toDelete.forEach(function(dir) {
    cs.evalScript('clDeleteTemplate(' + JSON.stringify(dir) + ')', function() {
      if (--pending === 0) {
        showProgress(false);
        state.templates = state.templates.filter(function(t) {
          return toDelete.indexOf(t.templateDir) < 0;
        });
        renderSidebar();
        renderGrid(getFilteredTemplates());
        setStatus('\u2713 Deleted ' + toDelete.length + ' comp' + (toDelete.length === 1 ? '' : 's'), 'success');
        setTimeout(function() { setStatus('', ''); }, 3000);
      }
    });
  });
}

function bulkExport() {
  var dirs = Object.keys(state.selected);
  exitSelectMode();
  openExportModal(dirs);
}

function openBulkMoveMenu() {
  closeCardMenu();
  var dirs = Object.keys(state.selected);
  if (dirs.length === 0) return;

  var menu = document.createElement('div');
  menu.className = 'card-menu-dropdown';

  if (state.folders.length > 0) {
    var title = document.createElement('div');
    title.className   = 'menu-section-title';
    title.textContent = 'Move to';
    menu.appendChild(title);

    state.folders.forEach(function(folderName) {
      var item = document.createElement('div');
      item.className   = 'menu-item';
      item.innerHTML   = '&#128193; ' + escHtml(folderName);
      item.addEventListener('click', function() { closeCardMenu(); bulkMoveToFolder(folderName); });
      menu.appendChild(item);
    });
  }

  var newFolderItem = document.createElement('div');
  newFolderItem.className   = 'menu-item';
  newFolderItem.textContent = '+ New folder\u2026';
  newFolderItem.addEventListener('click', function() {
    closeCardMenu();
    var name = prompt('New folder name:');
    if (!name || !name.trim()) return;
    createFolder(name.trim(), function() { bulkMoveToFolder(name.trim()); });
  });
  menu.appendChild(newFolderItem);

  var removeItem = document.createElement('div');
  removeItem.className   = 'menu-item';
  removeItem.textContent = 'Remove from folder';
  removeItem.addEventListener('click', function() { closeCardMenu(); bulkMoveToFolder(''); });
  menu.appendChild(removeItem);

  document.body.appendChild(menu);
  _menuDropdown = menu;

  // Position above the Move button
  var btn  = document.getElementById('selMoveBtn');
  var rect = btn.getBoundingClientRect();
  var menuW = 168;
  var left  = Math.max(8, Math.min(rect.left, window.innerWidth - menuW - 8));
  menu.style.left   = left + 'px';
  menu.style.top    = 'auto';
  menu.style.bottom = (window.innerHeight - rect.top + 4) + 'px';

  setTimeout(function() {
    _menuOutsideFn = function() { closeCardMenu(); };
    document.addEventListener('click', _menuOutsideFn);
  }, 0);
}

function bulkMoveToFolder(folderName) {
  var templates = Object.keys(state.selected).map(function(dir) { return state.selected[dir]; });
  var pending   = templates.length;
  showProgress(true);

  templates.forEach(function(t) {
    cs.evalScript(
      'clUpdateMeta(' + JSON.stringify(t.templateDir) + ',' + JSON.stringify('{"folder":' + JSON.stringify(folderName) + '}') + ')',
      function() {
        t.folder = folderName;
        if (--pending === 0) {
          showProgress(false);
          exitSelectMode();
          renderSidebar();
          renderGrid(getFilteredTemplates());
          var dest = folderName ? '\u201c' + folderName + '\u201d' : 'All Comps';
          setStatus('\u2713 Moved ' + templates.length + ' comp' + (templates.length === 1 ? '' : 's') + ' to ' + dest, 'success');
          setTimeout(function() { setStatus('', ''); }, 3000);
        }
      }
    );
  });
}

// ── Plugin update ─────────────────────────────────────────────────────────

function cpVersionGt(a, b) {
  var parse = function(v) { return v.split('.').map(function(n) { return parseInt(n) || 0; }); };
  var av = parse(a), bv = parse(b);
  if (av[0] !== bv[0]) return av[0] > bv[0];
  if (av[1] !== bv[1]) return av[1] > bv[1];
  return av[2] > bv[2];
}

function cpSetUpdateStatus(msg, kind) {
  var el = document.getElementById('updateStatusText');
  if (!el) return;
  el.textContent = msg;
  el.style.color =
    kind === 'success' ? 'var(--accent)' :
    kind === 'error'   ? 'var(--error)'  :
    'var(--text-muted)';
}

// Paint the auto-update button to match current state. Skips while an install
// is in flight (data-installing flag set) so the state machine never clobbers
// the "Installing v…" label mid-install.
function cpSetAutoBtnState(state, version) {
  var btn = document.getElementById('updAutoBtn');
  if (!btn) return;
  if (btn.dataset.installing === '1') return;
  switch (state) {
    case 'available':
      btn.disabled = false;
      btn.textContent = 'Update to v' + version;
      var v1 = document.getElementById('updAutoVersion');
      if (v1) v1.textContent = 'v' + version;
      break;
    case 'uptodate':
      btn.disabled = true;
      btn.textContent = 'Up to date (v' + version + ')';
      var v2 = document.getElementById('updAutoVersion');
      if (v2) v2.textContent = 'v' + version;
      break;
    case 'unreachable':
      btn.disabled = true;
      btn.textContent = 'Update server unreachable';
      break;
    case 'checking':
      btn.disabled = true;
      btn.textContent = 'Checking…';
      break;
  }
}

// Tries each manifest URL in order; resolves with { data, host } on first success
// or { error } if every host fails. Logs every attempt to console for diagnostics.
// The GitHub Contents API URL is special-cased: response is base64-encoded inside
// a JSON envelope, so we decode it before returning.
function cpFetchLatestJson() {
  var cacheBust = '?t=' + Date.now() + '-' + Math.random().toString(36).slice(2);
  return CP_LATEST_URLS.reduce(function(promise, baseUrl) {
    return promise.then(function(prev) {
      if (prev && prev.data) return prev;
      var isGitHubApi = /^https:\/\/api\.github\.com\//.test(baseUrl);
      var url = isGitHubApi ? baseUrl : (baseUrl + (baseUrl.indexOf('?') >= 0 ? '&' : '?') + cacheBust.slice(1));
      var hostMatch = baseUrl.match(/^https?:\/\/([^/]+)/);
      var host = hostMatch ? hostMatch[1] : baseUrl;
      var headers = { 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache' };
      if (isGitHubApi) headers['Accept'] = 'application/vnd.github.v3+json';
      return fetch(url, { cache: 'no-store', headers: headers }).then(function(res) {
        if (!res.ok) {
          var err = host + ' → HTTP ' + res.status;
          console.warn('[CompPacks] manifest fetch failed:', err);
          return { error: err };
        }
        if (isGitHubApi) {
          return res.json().then(function(envelope) {
            if (!envelope || envelope.encoding !== 'base64' || !envelope.content) {
              var err = host + ' → unexpected API response shape';
              console.warn('[CompPacks] manifest fetch failed:', err);
              return { error: err };
            }
            try {
              var json = atob(envelope.content.replace(/\s/g, ''));
              var data = JSON.parse(json);
              console.log('[CompPacks] manifest fetched from ' + host + ' → v' + (data && data.version));
              return { data: data, host: host };
            } catch(e) {
              var err2 = host + ' → ' + (e && e.message ? e.message : String(e));
              console.warn('[CompPacks] manifest fetch failed:', err2);
              return { error: err2 };
            }
          });
        }
        return res.json().then(function(data) {
          console.log('[CompPacks] manifest fetched from ' + host + ' → v' + (data && data.version));
          return { data: data, host: host };
        }, function(e) {
          var err = host + ' → ' + (e && e.message ? e.message : 'invalid JSON');
          console.warn('[CompPacks] manifest fetch failed:', err);
          return { error: err };
        });
      }, function(e) {
        var err = host + ' → ' + (e && e.message ? e.message : String(e));
        console.warn('[CompPacks] manifest fetch failed:', err);
        return { error: err };
      });
    });
  }, Promise.resolve(null)).then(function(final) {
    return final && final.data ? final : { error: (final && final.error) || 'all manifest hosts unreachable' };
  });
}

// Multi-host zip download fallback used by cpInstallFromUrl. If the manifest's
// updateUrl is on raw.githubusercontent.com, we also try jsDelivr as backup.
function cpZipUrlCandidates(updateUrl) {
  if (!updateUrl) return [];
  var m = updateUrl.match(/^https?:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/);
  if (!m) return [updateUrl];
  return [
    updateUrl,
    'https://cdn.jsdelivr.net/gh/' + m[1] + '/' + m[2] + '@' + m[3] + '/' + m[4]
  ];
}

// cpCheckForUpdates(opts) - set opts.manual=true for user-triggered checks so
// a visible result is surfaced (success / no-update / error) rather than failing silently.
function cpCheckForUpdates(opts) {
  var manual = !!(opts && opts.manual);
  return cpFetchLatestJson().then(function(result) {
    if (!result || result.error || !result.data || !result.data.version) {
      var msg = (result && result.error) || 'manifest missing version field';
      console.warn('[CompPacks] update check failed:', msg);
      if (manual) cpSetUpdateStatus("Couldn't reach update server (" + msg + "). Use manual install below.", 'error');
      cpSetAutoBtnState('unreachable');
      return;
    }
    var data = result.data;
    var remote = String(data.version).trim();
    if (!cpVersionGt(remote, CP_VERSION)) {
      if (manual) cpSetUpdateStatus("You're up to date - running v" + CP_VERSION + '.', 'info');
      cpSetAutoBtnState('uptodate', CP_VERSION);
      availableUpdateVersion = null;
      availableUpdateUrl = null;
      return;
    }
    availableUpdateVersion = remote;
    availableUpdateUrl     = data.updateUrl || '';
    var banner = document.getElementById('updateBanner');
    var bannerVer = document.getElementById('updateBannerVersion');

    // Manual checks override the dismiss flag - the user explicitly asked.
    if (!manual && localStorage.getItem(LS_DISMISS_KEY) === remote) {
      cpSetAutoBtnState('available', remote);
      return;
    }
    if (banner && bannerVer) {
      bannerVer.textContent = 'v' + remote;
      banner.dataset.version = remote;
      banner.dataset.updateUrl = availableUpdateUrl;
      banner.classList.add('show');
    }
    cpSetAutoBtnState('available', remote);
    console.log('[CompPacks] Update available: v' + remote + ' (installed v' + CP_VERSION + ')');
    if (manual) cpSetUpdateStatus('Update v' + remote + ' available - banner shown at top.', 'success');
  });
}

// Open the SharePoint folder in the user's default browser
function cpOpenSharePointFolder() {
  try {
    if (typeof cep !== 'undefined' && cep.util && cep.util.openURLInDefaultBrowser) {
      cep.util.openURLInDefaultBrowser(CP_DOWNLOAD_URL);
      return;
    }
  } catch(_) {}
  if (_child) {
    var cmd = (_os && _os.platform() === 'win32')
      ? 'start "" "' + CP_DOWNLOAD_URL + '"'
      : 'open "' + CP_DOWNLOAD_URL + '"';
    try { _child.exec(cmd); } catch(_) {}
  }
}

// Download zip via multi-host fetch + delegate to cpInstallFromZip.
function cpInstallFromUrl(updateUrl, version) {
  var candidates = cpZipUrlCandidates(updateUrl);
  var verLabel = version ? 'v' + version : 'update';
  cpSetUpdateStatus('Downloading ' + verLabel + '…', 'info');

  var lastErr = '';
  var chain = Promise.resolve(null);
  candidates.forEach(function(url) {
    chain = chain.then(function(buf) {
      if (buf) return buf;
      var hostMatch = url.match(/^https?:\/\/([^/]+)/);
      var host = hostMatch ? hostMatch[1] : url;
      return fetch(url, { cache: 'no-store' }).then(function(res) {
        if (!res.ok) {
          lastErr = host + ' → HTTP ' + res.status;
          console.warn('[CompPacks] zip fetch failed:', lastErr);
          return null;
        }
        return res.arrayBuffer().then(function(ab) {
          var b = Buffer.from(ab);
          console.log('[CompPacks] zip downloaded from ' + host + ' (' + b.length + ' bytes)');
          return b;
        });
      }, function(e) {
        lastErr = host + ' → ' + (e && e.message ? e.message : String(e));
        console.warn('[CompPacks] zip fetch failed:', lastErr);
        return null;
      });
    });
  });
  return chain.then(function(buf) {
    if (!buf) throw new Error(lastErr || 'all mirrors unreachable');
    var tmpZip = _path.join(_os.tmpdir(), 'cp_update_' + Date.now() + '.zip');
    _fs.writeFileSync(tmpZip, buf);
    return cpInstallFromZip(tmpZip, version);
  });
}

// Shared install pipeline used by both auto-install and manual drop-zone.
// Extracts the zip, finds the plugin folder, replaces the installed extension,
// and re-enables CEP debug mode. Returns a Promise.
function cpInstallFromZip(zipPath, version) {
  return new Promise(function(resolve, reject) {
    if (!_fs || !_path || !_os || !_child) {
      reject(new Error('Node.js not available'));
      return;
    }
    var verLabel = version ? 'v' + version : 'update';
    cpSetUpdateStatus('Installing ' + verLabel + '…', 'info');

    var isWin  = _os.platform() === 'win32';
    var tmpDir = zipPath.replace(/\.zip$/, '') + '_extracted';
    function sq(p) { return "'" + p.replace(/'/g, "'\\''") + "'"; }

    try {
      _fs.mkdirSync(tmpDir, { recursive: true });
      if (isWin) {
        _child.execSync(
          "powershell -command \"Expand-Archive -Path '" + zipPath.replace(/'/g, "''") +
          "' -DestinationPath '" + tmpDir.replace(/'/g, "''") + "' -Force\"",
          { timeout: 30000 }
        );
      } else {
        _child.execSync('unzip -q ' + sq(zipPath) + ' -d ' + sq(tmpDir), { timeout: 30000 });
      }

      // Find a plugin folder inside the zip (must contain CSXS/manifest.xml).
      // Supports both flat zips (no wrapper folder) and wrapped zips.
      var installedPath = cs.getSystemPath(SystemPath.EXTENSION);
      var srcPluginPath = null;
      if (_fs.existsSync(_path.join(tmpDir, 'CSXS', 'manifest.xml'))) {
        srcPluginPath = tmpDir;
      } else {
        var entries = _fs.readdirSync(tmpDir);
        for (var i = 0; i < entries.length; i++) {
          var candidate = _path.join(tmpDir, entries[i]);
          if (_fs.statSync(candidate).isDirectory() &&
              _fs.existsSync(_path.join(candidate, 'CSXS', 'manifest.xml'))) {
            srcPluginPath = candidate;
            break;
          }
        }
      }
      if (!srcPluginPath) throw new Error('Plugin folder not found inside ZIP.');

      if (isWin) {
        _child.execSync('rmdir /s /q "' + installedPath + '"', { timeout: 10000 });
        _child.execSync('xcopy /e /i /q "' + srcPluginPath + '" "' + installedPath + '\\"', { timeout: 15000 });
      } else {
        _child.execSync('rm -rf ' + sq(installedPath), { timeout: 10000 });
        _child.execSync('cp -r ' + sq(srcPluginPath) + ' ' + sq(installedPath), { timeout: 15000 });
      }

      // Re-enable CEP debug mode (required for unsigned extensions)
      for (var v = 9; v <= 12; v++) {
        try {
          if (isWin) {
            _child.execSync('reg add "HKCU\\SOFTWARE\\Adobe\\CSXS.' + v + '" /v PlayerDebugMode /t REG_SZ /d 1 /f', { timeout: 3000 });
          } else {
            _child.execSync('defaults write com.adobe.CSXS.' + v + ' PlayerDebugMode 1', { timeout: 3000 });
          }
        } catch(_) {}
      }

      // Show the celebratory success card and hide the regular install UI
      cpShowInstallSuccess(version);
      resolve();
    } catch (e) {
      reject(e);
    } finally {
      try { _fs.unlinkSync(zipPath); } catch(_) {}
      try {
        if (isWin) _child.execSync('rmdir /s /q "' + tmpDir + '"', { timeout: 5000 });
        else       _child.execSync('rm -rf ' + sq(tmpDir),         { timeout: 5000 });
      } catch(_) {}
    }
  });
}

// Show the big celebratory success card and hide the regular install UI.
// Mirrors the ElevenLabs pattern — pulsing green checkmark + version + actions.
function cpShowInstallSuccess(version) {
  var card = document.getElementById('installSuccess');
  if (!card) return;
  var verEl = document.getElementById('installSuccessVersion');
  if (verEl && version) verEl.textContent = 'v' + version;

  // Hide all the regular install UI inside #updateOverlay
  var hide = function(sel) {
    var els = document.querySelectorAll(sel);
    for (var i = 0; i < els.length; i++) els[i].style.display = 'none';
  };
  hide('#updAutoBox');
  hide('#updateOverlay .upd-divider');
  hide('#updateOverlay .settings-info');
  hide('#updDropZone');
  hide('#updateOverlay .update-btn-row');
  hide('#updateOverlay .upd-footnote');
  hide('#updateStatusText');

  card.style.display = 'flex';
}

// Diagnostic helpers - callable from DevTools console
window.cpDiag = {
  check: function() { return cpCheckForUpdates({ manual: true }); },
  clear: function() { localStorage.removeItem(LS_DISMISS_KEY); },
  state: function() {
    return {
      installed: CP_VERSION,
      dismissed: localStorage.getItem(LS_DISMISS_KEY),
      banner:    (function() { var b = document.getElementById('updateBanner'); return b ? b.classList.contains('show') : 'missing'; })()
    };
  }
};

// ── Wire UI ───────────────────────────────────────────────────────────────

function wireUI() {
  document.getElementById('addCompBtn').addEventListener('click',      addSelectedComp);
  document.getElementById('importPackBtn').addEventListener('click',   importPack);
  document.getElementById('exportPackBtn').addEventListener('click',   function() { openExportModal(); });
  document.getElementById('exportCancelBtn').addEventListener('click', closeExportModal);
  document.getElementById('exportDoBtn').addEventListener('click',     doExport);
  document.getElementById('exportSelectAll').addEventListener('click',  function() {
    document.querySelectorAll('#exportCompList input[type="checkbox"]').forEach(function(cb) { cb.checked = true; });
  });
  document.getElementById('exportSelectNone').addEventListener('click', function() {
    document.querySelectorAll('#exportCompList input[type="checkbox"]').forEach(function(cb) { cb.checked = false; });
  });
  document.getElementById('selectModeBtn').addEventListener('click', function() {
    if (state.selectMode) exitSelectMode(); else enterSelectMode();
  });
  document.getElementById('selCancelBtn').addEventListener('click',  exitSelectMode);
  document.getElementById('selDeleteBtn').addEventListener('click',  bulkDelete);
  document.getElementById('selExportBtn').addEventListener('click',  bulkExport);
  document.getElementById('selMoveBtn').addEventListener('click',    openBulkMoveMenu);

  document.getElementById('refreshBtn').addEventListener('click',      loadFoldersThenTemplates);

  // Escape key → exit select mode
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && state.selectMode) exitSelectMode();
  });

  var sortSel = document.getElementById('sortSelect');
  sortSel.value = state.sortOrder;
  sortSel.addEventListener('change', function() {
    state.sortOrder = this.value;
    localStorage.setItem(LS_SORT_KEY, state.sortOrder);
    renderGrid(getFilteredTemplates());
  });
  document.getElementById('starterInstallBtn').addEventListener('click', installStarterPack);
  document.getElementById('starterDismissBtn').addEventListener('click', dismissStarterBanner);
  document.getElementById('searchInput').addEventListener('input',   function() {
    renderGrid(getFilteredTemplates());
  });
  document.getElementById('settingsBtn').addEventListener('click',   openSettings);
  document.getElementById('settingsCloseBtn').addEventListener('click',  closeSettings);
  document.getElementById('settingsChangeBtn').addEventListener('click', changeLibraryFolder);
  document.getElementById('settingsOpenBtn').addEventListener('click',   openLibraryInFinder);

  // ── Help overlay wiring ────────────────────────────────────────────────
  var helpBtn      = document.getElementById('helpBtn');
  var helpOverlay  = document.getElementById('helpOverlay');
  var helpCloseBtn = document.getElementById('helpCloseBtn');
  if (helpBtn && helpOverlay) {
    helpBtn.addEventListener('click', function() {
      // Close any other overlay first
      var so = document.getElementById('settingsOverlay');
      var uo = document.getElementById('updateOverlay');
      if (so) so.classList.remove('visible');
      if (uo) uo.classList.remove('visible');
      helpOverlay.classList.add('visible');
    });
  }
  if (helpCloseBtn) {
    helpCloseBtn.addEventListener('click', function() {
      helpOverlay.classList.remove('visible');
    });
  }

  // ── Update overlay wiring (banner + install panel) ─────────────────────
  var updateBanner   = document.getElementById('updateBanner');
  var updateOverlay  = document.getElementById('updateOverlay');
  var headerUpdBtn   = document.getElementById('updateBtn');
  var bannerBtn      = document.getElementById('updateBannerBtn');
  var bannerDismiss  = document.getElementById('updateBannerDismiss');
  var updAutoBtn     = document.getElementById('updAutoBtn');
  var updCheckBtn    = document.getElementById('updCheckBtn');
  var updCloseBtn    = document.getElementById('updateCloseBtn');
  var updOpenSP      = document.getElementById('updOpenSharePoint');
  var updDropZone    = document.getElementById('updDropZone');
  var updFileInput   = document.getElementById('updFileInput');
  var updDropLabel   = document.getElementById('updDropLabel');
  var installUpdBtn  = document.getElementById('installUpdateBtn');
  var reloadPanelBtn = document.getElementById('reloadPanelBtn');

  function openUpdateOverlay() {
    if (updateOverlay) updateOverlay.classList.add('visible');
    if (updateBanner)  updateBanner.classList.remove('show');
    // If the success card is showing from a previous install, reset back to
    // the normal install state so a fresh check can run.
    cpResetInstallUI();
    // Auto-trigger a fresh check on every overlay open so the user sees current state
    cpSetAutoBtnState('checking');
    cpSetUpdateStatus('Checking for updates…', 'info');
    cpCheckForUpdates({ manual: true });
  }
  function closeUpdateOverlay() {
    if (updateOverlay) updateOverlay.classList.remove('visible');
  }

  // Restore the install UI after a success card was shown (e.g. user clicks
  // "Later" then re-opens the overlay).
  function cpResetInstallUI() {
    var success = document.getElementById('installSuccess');
    if (success) success.style.display = 'none';
    var show = function(sel, mode) {
      var els = document.querySelectorAll(sel);
      for (var i = 0; i < els.length; i++) els[i].style.display = mode || '';
    };
    show('#updAutoBox', 'flex');
    show('#updateOverlay .upd-divider');
    show('#updateOverlay .settings-info');
    show('#updDropZone', 'flex');
    show('#updateOverlay .update-btn-row', 'flex');
    show('#updateOverlay .upd-footnote');
    show('#updateStatusText');
  }

  if (headerUpdBtn) headerUpdBtn.addEventListener('click', openUpdateOverlay);
  if (bannerBtn)    bannerBtn.addEventListener('click', openUpdateOverlay);
  if (updCloseBtn)  updCloseBtn.addEventListener('click', closeUpdateOverlay);
  if (bannerDismiss) {
    bannerDismiss.addEventListener('click', function() {
      var v = updateBanner ? updateBanner.dataset.version : '';
      if (v) localStorage.setItem(LS_DISMISS_KEY, v);
      if (updateBanner) updateBanner.classList.remove('show');
    });
  }
  if (updOpenSP) {
    updOpenSP.addEventListener('click', function(e) {
      e.preventDefault();
      cpOpenSharePointFolder();
    });
  }

  // Auto-update button — fetches GitHub-hosted zip and installs in-place
  if (updAutoBtn) {
    updAutoBtn.addEventListener('click', function() {
      if (updAutoBtn.disabled) return;
      var url = availableUpdateUrl;
      var ver = availableUpdateVersion;
      if (!url) {
        cpSetUpdateStatus("You're already on the latest version (v" + CP_VERSION + ").", 'info');
        return;
      }
      updAutoBtn.dataset.installing = '1';
      updAutoBtn.disabled = true;
      updAutoBtn.textContent = ver ? 'Installing v' + ver + '…' : 'Installing…';
      cpInstallFromUrl(url, ver).catch(function(e) {
        cpSetUpdateStatus('Update failed: ' + e.message, 'error');
        updAutoBtn.textContent = ver ? 'Update to v' + ver : 'Try again';
        updAutoBtn.disabled = false;
      }).then(function() {
        delete updAutoBtn.dataset.installing;
      });
    });
  }

  // Manual "Check for updates" link
  if (updCheckBtn) {
    updCheckBtn.addEventListener('click', function() {
      updCheckBtn.disabled = true;
      var oldLabel = updCheckBtn.textContent;
      updCheckBtn.textContent = 'Checking…';
      cpSetAutoBtnState('checking');
      cpSetUpdateStatus('Checking for updates…', 'info');
      cpCheckForUpdates({ manual: true }).then(function() {
        updCheckBtn.disabled = false;
        updCheckBtn.textContent = oldLabel;
      });
    });
  }

  // Manual drop-zone — drop or browse a -update.zip
  function setDropZoneFile(filePath) {
    _updZipPath = filePath;
    var name = filePath ? filePath.split(/[\\/]/).pop() : '';
    if (updDropLabel) updDropLabel.textContent = name || 'Drop .zip here or click to browse';
    if (updDropZone)  updDropZone.classList.toggle('has-file', !!filePath);
    if (installUpdBtn) installUpdBtn.disabled = !filePath;
    if (reloadPanelBtn) reloadPanelBtn.style.display = 'none';
  }
  if (updDropZone) {
    updDropZone.addEventListener('click', function() { if (updFileInput) updFileInput.click(); });
    updDropZone.addEventListener('dragover', function(e) {
      e.preventDefault();
      updDropZone.classList.add('drag-over');
    });
    updDropZone.addEventListener('dragleave', function() {
      updDropZone.classList.remove('drag-over');
    });
    updDropZone.addEventListener('drop', function(e) {
      e.preventDefault();
      updDropZone.classList.remove('drag-over');
      var f = e.dataTransfer.files && e.dataTransfer.files[0];
      if (f && f.name.toLowerCase().endsWith('.zip')) setDropZoneFile(f.path);
      else cpSetUpdateStatus('Please drop a .zip file.', 'error');
    });
  }
  if (updFileInput) {
    updFileInput.addEventListener('change', function() {
      var f = this.files && this.files[0];
      if (f && f.name.toLowerCase().endsWith('.zip')) setDropZoneFile(f.path);
    });
  }
  if (installUpdBtn) {
    installUpdBtn.addEventListener('click', function() {
      if (!_updZipPath) return;
      installUpdBtn.disabled = true;
      // Best-effort version detection from filename: CompPacks-X.Y.Z-update.zip
      var verMatch = (_updZipPath.match(/CompPacks-([0-9][0-9.]*)-update\.zip$/i)) || [];
      // Copy to tmp first so cpInstallFromZip's cleanup doesn't delete the user's source
      var tmpZip = _path.join(_os.tmpdir(), 'cp_update_' + Date.now() + '.zip');
      try {
        _fs.copyFileSync(_updZipPath, tmpZip);
      } catch(e) {
        cpSetUpdateStatus('Could not stage zip: ' + e.message, 'error');
        installUpdBtn.disabled = false;
        return;
      }
      cpInstallFromZip(tmpZip, verMatch[1] || null).catch(function(e) {
        cpSetUpdateStatus('Install failed: ' + e.message, 'error');
        installUpdBtn.disabled = false;
      });
    });
  }
  if (reloadPanelBtn) {
    reloadPanelBtn.addEventListener('click', function() { window.location.reload(); });
  }

  // Success card buttons — Reload Panel (primary) + Later (close overlay)
  var installReloadBtn   = document.getElementById('installReloadBtn');
  var installSuccessClose = document.getElementById('installSuccessClose');
  if (installReloadBtn) {
    installReloadBtn.addEventListener('click', function() { window.location.reload(); });
  }
  if (installSuccessClose) {
    installSuccessClose.addEventListener('click', closeUpdateOverlay);
  }

  // Fixed sidebar items
  document.getElementById('folderAll').addEventListener('click',  function() { closeCardMenu(); setActiveFolder('all'); });
  document.getElementById('folderFavs').addEventListener('click', function() { closeCardMenu(); setActiveFolder('favorites'); });

  // New folder button
  document.getElementById('sidebarAddFolder').addEventListener('click', function() {
    var name = prompt('New folder name:');
    if (!name || !name.trim()) return;
    name = name.trim();
    if (state.folders.indexOf(name) >= 0) { setActiveFolder(name); return; }
    createFolder(name, function() { setActiveFolder(name); });
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────

function updateStatusCount() {
  var filtered = getFilteredTemplates();
  var label = state.activeFolder === 'all'
    ? state.templates.length + ' comp' + (state.templates.length === 1 ? '' : 's') + ' in library'
    : filtered.length + ' comp' + (filtered.length === 1 ? '' : 's');
  setStatus(label, 'info');
}

function setStatus(msg, type) {
  var el     = document.getElementById('statusMsg');
  el.textContent = msg;
  el.className   = 'status' + (type ? ' ' + type : '');
}

function showProgress(on) {
  document.getElementById('progressBar').classList[on ? 'add' : 'remove']('visible');
}

function formatDuration(sec) {
  var m = Math.floor(sec / 60);
  var s = (sec % 60).toFixed(1);
  if (m > 0) return m + ':' + (parseFloat(s) < 10 ? '0' : '') + s;
  return s + 's';
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function escAttr(s) {
  return String(s).replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
